//
//  MyMainWindow.m
//  ImageView
//
//  Created by Dun-Yu Hsiao on 9/30/09.
//  Copyright 2009 __MyCompanyName__. All rights reserved.
//

#import "MyMainWindow.h"
#import "ImageViewAppDelegate.h"
#import "GYImageView.h"

@implementation MyMainWindow


- (void)dealloc
{
	[theDelegate release];
}

- (void) detectTouch:(CGPoint)p withPhase:(UITouchPhase)phase {
	
	
	if (phase == UITouchPhaseBegan) {
		theDelegate.touchStartPoint = p;
		theDelegate.touchEndPoint = CGPointMake (-10.0f,-10.0f);
		click_Ind = TRUE;
		//NSLog([NSString stringWithFormat:@"%f, %f", theDelegate.touchStartPoint.x,theDelegate.touchStartPoint.y]);
		//NSLog(@"UITouchPhaseBegan");
		movingSpan.x = fabs(theDelegate.maxLatLon.x-theDelegate.minLatLon.x);
		movingSpan.y = fabs(theDelegate.maxLatLon.y-theDelegate.minLatLon.y);
		movingCenter.x = (theDelegate.maxLatLon.x+theDelegate.minLatLon.x)/2;
		movingCenter.y = (theDelegate.maxLatLon.y+theDelegate.minLatLon.y)/2;
		//[ [theDelegate.viewController imageView]  touchesBegan:allTouches withEvent:event];
		
	}
	if (phase == UITouchPhaseMoved) {
		theDelegate.touchMovingPoint = p;
		//NSLog([NSString stringWithFormat:@"%f, %f", theDelegate.touchMovingPoint.x,theDelegate.touchMovingPoint.y]);
		//NSLog(@"UITouchPhaseMoved");
		//[ [theDelegate.viewController glView] startAnimation];
		
		click_Ind = FALSE;
		
		/*
		 // X displacement,Y displacement + center = new center
		 CLLocationCoordinate2D new_center;
		 CLLocationCoordinate2D tmp_center;
		 CLLocationCoordinate2D old_center;
		 old_center=theDelegate.movingCenter;
		 new_center.latitude = (CLLocationDegrees)(float)(theDelegate.touchMovingPoint.y-theDelegate.touchStartPoint.y)*movingSpan.x/480.0/1.3 + movingCenter.x;
		 new_center.longitude = (CLLocationDegrees)-(float)(theDelegate.touchMovingPoint.x-theDelegate.touchStartPoint.x)*movingSpan.y/320.0/1.5 + movingCenter.y;
		 //NSLog(@"%f %f %f %f", (theDelegate.touchMovingPoint.y-theDelegate.touchStartPoint.y), movingSpan.x, movingCenter.x,(theDelegate.touchMovingPoint.y-theDelegate.touchStartPoint.y)*movingSpan.x/480.0 + movingCenter.x);
		 
		 //TODO: sent to nitification center of mapview, close user interaction on mapview
		 
		 float step = 10.0;
		 for (float i = 1; i <= step; i++)
		 {
		 tmp_center.latitude = old_center.latitude * (step-i)/step + new_center.latitude * i/step;
		 tmp_center.longitude = old_center.longitude * (step-i)/step + new_center.longitude * i/step;
		 theDelegate.movingCenter=tmp_center;
		 [[NSNotificationCenter defaultCenter] postNotificationName:Change_Center object:nil];
		 }
		 */
		
		//	theDelegate.movingCenter=new_center;
		//	[[NSNotificationCenter defaultCenter] postNotificationName:Change_Center object:nil];
		
		
		//[[[theDelegate.viewController imageView] mapview] setCenterCoordinate:tmp_center animated:YES];
	}
	if (phase == UITouchPhaseEnded) {
		theDelegate.touchEndPoint = p;
		theDelegate.touchStartPoint = CGPointMake (0.0f,0.0f);
		theDelegate.touchMovingPoint = CGPointMake (0.0f,0.0f);
		//NSLog([NSString stringWithFormat:@"%f, %f", theDelegate.touchEndPoint.x,theDelegate.touchEndPoint.y]);
		if(click_Ind)
		{
			[[NSNotificationCenter defaultCenter] postNotificationName:Find_Flag object:nil];
			
			click_Ind = FALSE;
		}
		//NSLog(@"UITouchPhaseEnded");
		
	}
	
}


- (void) sendEvent:(UIEvent*)event {
//	NSLog(@"mymain Send Event");
	theDelegate = (ImageViewAppDelegate*)[[UIApplication sharedApplication] delegate];
	NSSet *allTouches = [event allTouches];
	
	UITouchPhase phase = ((UITouch *)[allTouches anyObject]).phase;
    
	if ([allTouches count] > 0) {
        // allTouches count only ever seems to be 1, so anyObject works here.
       
		UITouch *t = [[allTouches allObjects] objectAtIndex:0];
		CGPoint touchPos = [t locationInView:self];
		CGRect bounds = [self bounds];
		// This takes our point and makes it into a "percentage" of the screen
		//   That is 0.85 = 85%
		CGPoint p = CGPointMake((touchPos.x - bounds.origin.x) / bounds.size.width,
								(touchPos.y - bounds.origin.y) / bounds.size.height);
		p.x=p.x*320;
		p.y=p.y*480;
		
		if ( p.y >= 70 && p.y <= 440)  //available touch region
		{
		
			if (theDelegate.touchStatus == 1) //hoverview
			{
				if ( p.x <= 0.95*320 && p.x >= 8 && p.y >= 72 && p.y <= 0.39*480)  
				{}
			}
			//NSLog([NSString stringWithFormat:@"%f, %f", p.x*320,p.y*480]);
			
			//detect touch
			[self detectTouch:p withPhase:phase];
		}
           
    }
	[super sendEvent:event];
	//[ [theDelegate.viewController imageView] sendEvent:event];
} 

@end

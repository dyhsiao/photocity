//
//  CSMapRouteLayerView.m
//  mapLines
//
//  Created by Craig on 4/12/09.
//  Copyright 2009 __MyCompanyName__. All rights reserved.
//

#import "CSMapRouteLayerView.h"
#import "ImageViewAppDelegate.h"


@implementation CSMapRouteLayerView
@synthesize mapView   = _mapView;
@synthesize points    = _points;
@synthesize lineColor = _lineColor; 
@synthesize theDelegate;

-(id) initWithRoute:(NSArray*)routePoints mapView:(MKMapView*)mapView
{
	self = [super initWithFrame:CGRectMake(0, 0, mapView.frame.size.width, mapView.frame.size.height)];
	[self setBackgroundColor:[UIColor clearColor]];
	
	theDelegate = (ImageViewAppDelegate*)[[UIApplication sharedApplication] delegate];
	
	//[NSTimer scheduledTimerWithTimeInterval:1.0/60.0 target:self selector:@selector(getCoord) userInfo:nil repeats:YES];
	

	updateCoord = 0;
	
	[self setMapView:mapView];
	[self setPoints:routePoints];
	
	// determine the extents of the trip points that were passed in, and zoom in to that area. 
	CLLocationDegrees maxLat = -90;
	CLLocationDegrees maxLon = -180;
	CLLocationDegrees minLat = 90;
	CLLocationDegrees minLon = 180;
	
	for(int idx = 0; idx < self.points.count; idx++)
	{
		CLLocation* currentLocation = [self.points objectAtIndex:idx];
		if(currentLocation.coordinate.latitude > maxLat)
			maxLat = currentLocation.coordinate.latitude;
		if(currentLocation.coordinate.latitude < minLat)
			minLat = currentLocation.coordinate.latitude;
		if(currentLocation.coordinate.longitude > maxLon)
			maxLon = currentLocation.coordinate.longitude;
		if(currentLocation.coordinate.longitude < minLon)
			minLon = currentLocation.coordinate.longitude;
	}
	
	MKCoordinateRegion region;
	region.center.latitude     = 47.655;//(maxLat + minLat) / 2;
	region.center.longitude    = -122.305;//(maxLon + minLon) / 2;
	region.span.latitudeDelta  = (maxLat - minLat)/16;
	region.span.longitudeDelta = (maxLon - minLon)/16;
	
	[self.mapView setRegion:region animated:NO];
	[self.mapView regionThatFits:region];
	[self.mapView setCenterCoordinate:region.center animated:NO];
	[self.mapView setDelegate:self];
	[self.mapView addSubview:self];
	
	
	return self;
}


- (void)drawRect:(CGRect)rect
{
	// only draw our lines if we're not int he moddie of a transition and we 
	// acutally have some points to draw. 
	/*
	if(!self.hidden && nil != self.points && self.points.count > 0)
	{
		CGContextRef context = UIGraphicsGetCurrentContext(); 
		
		if(nil == self.lineColor)
			self.lineColor = [UIColor blueColor];
		
		CGContextSetStrokeColorWithColor(context, self.lineColor.CGColor);
		CGContextSetRGBFillColor(context, 0.0, 0.0, 1.0, 1.0);

		// Draw them with a 2.0 stroke width so they are a bit more visible.
		CGContextSetLineWidth(context, 2.0);
		
		for(int idx = 0; idx < self.points.count; idx++)
		{
			CLLocation* location = [self.points objectAtIndex:idx];
			CGPoint point = [_mapView convertCoordinate:location.coordinate toPointToView:self];
			
			if(idx == 0)
			{
				// move to the first point
				CGContextMoveToPoint(context, point.x, point.y);
			}
			else
			{
				CGContextAddLineToPoint(context, point.x, point.y);
			}

		}
		CGContextStrokePath(context);
	*/
		
//		CLLocation* location = [self.points objectAtIndex:self.points.count-1];
//		CGPoint point = [_mapView convertCoordinate:location.coordinate toPointToView:self];
//		CGContextMoveToPoint(context, point.x, point.y);
//		CGContextSetStrokeColorWithColor(context, [UIColor redColor].CGColor);
		//center
//		CGPoint point = [_mapView convertCoordinate:mapArea.center toPointToView:self];
//		CGContextMoveToPoint(context, point.x, point.y);
		//upper left
//		CLLocationCoordinate2D corner;
//		corner.latitude = mapArea.center.latitude + mapArea.span.latitudeDelta;
//		corner.longitude = mapArea.center.longitude + mapArea.span.longitudeDelta;
//		point = [_mapView convertCoordinate:corner toPointToView:self];
//		CGContextAddLineToPoint(context, point.x, point.y);
//		CGContextStrokePath(context);
		
		//get corners
	[self getCoord];

	//	[NSTimer scheduledTimerWithTimeInterval:0.1 target:self selector:@selector(showGLView) userInfo:nil repeats:false];
		
		
	
}

- (void)updaterThread {
	while(updateCoord) {
		NSAutoreleasePool *pool = [[NSAutoreleasePool alloc] init];
		[self performSelectorOnMainThread:@selector(getCoord) withObject:nil waitUntilDone:NO];
		[NSThread sleepForTimeInterval:0.1];
		[pool release];
	}
}

- (void) getCoord {
	//get corners
	float x_ext = 0.25;
	float y_ext = 0.15;
	
	MKCoordinateRegion mapArea = [_mapView convertRect:CGRectMake(-x_ext*self.frame.size.width, -y_ext*self.frame.size.height, (1+x_ext*2)*self.frame.size.width, (1+y_ext*2)*self.frame.size.height) toRegionFromView:self] ;
	//MKCoordinateRegion mapArea = [_mapView convertRect:CGRectMake(0,0,320,480) toRegionFromView:self] ;
	
	theDelegate.minLatLon = CGPointMake( mapArea.center.latitude + mapArea.span.latitudeDelta, mapArea.center.longitude - mapArea.span.longitudeDelta);
	theDelegate.maxLatLon = CGPointMake( mapArea.center.latitude - mapArea.span.latitudeDelta, mapArea.center.longitude + mapArea.span.longitudeDelta);

	//NSLog(@"getCoord %f %f %f %f", theDelegate.minLatLon.x, theDelegate.maxLatLon.x, theDelegate.minLatLon.y, theDelegate.maxLatLon.y );
	[theDelegate saveState];
	[[theDelegate.viewController glView] drawView];

}

/*
- (void) showGLView {
	[[theDelegate.viewController glView] setHidden:NO];
}
*/

#pragma mark mapView delegate functions



- (void)mapView:(MKMapView *)mapView regionWillChangeAnimated:(BOOL)animated
{
	// turn off the view of the route as the map is chaning regions. This prevents
	// the line from being displayed at an incorrect positoin on the map during the
	// transition. 
	//self.hidden = YES;
	//[NSThread detachNewThreadSelector:@selector(updaterThread) toTarget:self withObject:nil];
	updateCoord = 1;
	//[[theDelegate.viewController glView] setHidden:YES];
	[self setNeedsDisplay];
}
- (void)mapView:(MKMapView *)mapView regionDidChangeAnimated:(BOOL)animated
{
	// re-enable and re-poosition the route display. 
	//self.hidden = NO;
	[self setNeedsDisplay];
	updateCoord = 0;
	//[[theDelegate.viewController glView] setHidden:NO];
}

-(void) dealloc
{
	[theDelegate release];
	[_points release];
	[_mapView release];
	[super dealloc];
}




@end

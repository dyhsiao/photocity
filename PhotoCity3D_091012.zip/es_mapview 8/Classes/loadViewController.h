//
//  loadViewController.h
//  ImageView
//
//  Created by Dun-Yu Hsiao on 5/27/09.
//  Copyright 2009 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>


@interface loadViewController : UIViewController {

}

@end

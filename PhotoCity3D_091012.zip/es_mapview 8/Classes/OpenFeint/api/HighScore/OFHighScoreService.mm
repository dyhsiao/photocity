////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
/// 
///  Copyright 2009 Aurora Feint, Inc.
/// 
///  Licensed under the Apache License, Version 2.0 (the "License");
///  you may not use this file except in compliance with the License.
///  You may obtain a copy of the License at
///  
///  	http://www.apache.org/licenses/LICENSE-2.0
///  	
///  Unless required by applicable law or agreed to in writing, software
///  distributed under the License is distributed on an "AS IS" BASIS,
///  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
///  See the License for the specific language governing permissions and
///  limitations under the License.
/// 
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

#import "OFDependencies.h"
#import "OFHighScoreService.h"
#import "OFHttpNestedQueryStringWriter.h"
#import "OFService+Private.h"
#import "OFHighScore.h"
#import "OFLeaderboard.h"
#import "OFNotificationData.h"
#import "OFHighScoreService+Private.h"
#import "OFDelegateChained.h"
#import "OpenFeint+UserOptions.h"
#import "OpenFeint+Private.h"
#import "OFReachability.h"
#import "OFUser.h"
#import "OFNotification.h"

OPENFEINT_DEFINE_SERVICE_INSTANCE(OFHighScoreService);

@implementation OFHighScoreService

OPENFEINT_DEFINE_SERVICE(OFHighScoreService);

- (void) populateKnownResources:(OFResourceNameMap*)namedResources
{
	namedResources->addResource([OFHighScore getResourceName], [OFHighScore class]);
}

+ (void) getPage:(NSInteger)pageIndex forLeaderboard:(NSString*)leaderboardId friendsOnly:(BOOL)friendsOnly onSuccess:(const OFDelegate&)onSuccess onFailure:(const OFDelegate&)onFailure
{
	[OFHighScoreService getPage:pageIndex forLeaderboard:leaderboardId friendsOnly:friendsOnly silently:NO onSuccess:onSuccess onFailure:onFailure];
}

+ (void) getPage:(NSInteger)pageIndex forLeaderboard:(NSString*)leaderboardId friendsOnly:(BOOL)friendsOnly silently:(BOOL)silently onSuccess:(const OFDelegate&)onSuccess onFailure:(const OFDelegate&)onFailure
{
	[OFHighScoreService getPage:pageIndex
				 forLeaderboard:leaderboardId
			   comparedToUserId:nil
					friendsOnly:friendsOnly
					   silently:silently
					  onSuccess:onSuccess
					  onFailure:onFailure];
}

+ (void) getPage:(NSInteger)pageIndex 
  forLeaderboard:(NSString*)leaderboardId 
comparedToUserId:(NSString*)comparedToUserId 
	 friendsOnly:(BOOL)friendsOnly
		silently:(BOOL)silently
	   onSuccess:(const OFDelegate&)onSuccess 
	   onFailure:(const OFDelegate&)onFailure
{
	OFPointer<OFHttpNestedQueryStringWriter> params = new OFHttpNestedQueryStringWriter;
	params->io("leaderboard_id", leaderboardId);
	params->io("page", pageIndex);
	
	if (friendsOnly)
	{
		bool friendsLeaderboard = true;
		OFRetainedPtr<NSString> followerId = @"me";
		params->io("friends_leaderboard", friendsLeaderboard);
		params->io("follower_id", followerId);
	}
	
	if (comparedToUserId && [comparedToUserId length] > 0)
	{
		params->io("compared_user_id", comparedToUserId);
	}
	
	OFActionRequestType requestType = silently ? OFActionRequestSilent : OFActionRequestForeground;
	
	[[self sharedInstance] 
	 getAction:@"client_applications/@me/high_scores.xml"
	 withParameters:params
	 withSuccess:onSuccess
	 withFailure:onFailure
	 withRequestType:requestType
	 withNotice:[OFNotificationData foreGroundDataWithText:@"Downloaded High Scores"]];
}

+ (void) getLocalHighScores:(NSString*)leaderboardId onSuccess:(const OFDelegate&)onSuccess onFailure:(const OFDelegate&)onFailure
{
	[OFHighScoreService getHighScoresLocal:leaderboardId onSuccess:onSuccess onFailure:onFailure];
}

+ (void) getPageWithLoggedInUserForLeaderboard:(NSString*)leaderboardId onSuccess:(const OFDelegate&)onSuccess onFailure:(const OFDelegate&)onFailure
{
	OFPointer<OFHttpNestedQueryStringWriter> params = new OFHttpNestedQueryStringWriter;
	params->io("leaderboard_id", leaderboardId);	
	params->io("near_user_id", @"me");
	
	[[self sharedInstance]
	 getAction:@"client_applications/@me/high_scores.xml"
	 withParameters:params
	 withSuccess:onSuccess
	 withFailure:onFailure
	 withRequestType:OFActionRequestForeground
	 withNotice:[OFNotificationData foreGroundDataWithText:@"Downloaded High Scores"]];
}

- (void)_onSetHighScore:(NSArray*)resources nextCall:(OFDelegateChained*)nextCall
{
	//NSString* lastLoggedInUser = [OpenFeint lastLoggedInUserId];
	unsigned int highScoreCnt = [resources count];
	for (int i = 0; i < highScoreCnt; i++ )
	{
	OFHighScore* highScore = [resources objectAtIndex:i];
		[OFHighScoreService 
		 localSetHighScore:highScore.score
		 forLeaderboard:[NSString stringWithFormat:@"%d", highScore.leaderboardId]
		 forUser:highScore.user.resourceId
		 displayText:highScore.displayText
		 serverDate:[NSDate date]
	 	 addToExisting:NO];
	}
	[nextCall invoke];
}

+ (void) setHighScore:(int64_t)score forLeaderboard:(NSString*)leaderboardId onSuccess:(const OFDelegate&)onSuccess onFailure:(const OFDelegate&)onFailure
{
	[OFHighScoreService setHighScore:score withDisplayText:nil forLeaderboard:leaderboardId silently:NO onSuccess:onSuccess onFailure:onFailure];
}

+ (void) setHighScore:(int64_t)score forLeaderboard:(NSString*)leaderboardId silently:(BOOL)silently onSuccess:(const OFDelegate&)onSuccess onFailure:(const OFDelegate&)onFailure
{	
	[OFHighScoreService setHighScore:score withDisplayText:nil forLeaderboard:leaderboardId silently:silently onSuccess:onSuccess onFailure:onFailure];
}

+ (void) setHighScore:(int64_t)score withDisplayText:(NSString*)displayText forLeaderboard:(NSString*)leaderboardId onSuccess:(const OFDelegate&)onSuccess onFailure:(const OFDelegate&)onFailure
{
	[OFHighScoreService setHighScore:score withDisplayText:displayText forLeaderboard:leaderboardId silently:NO onSuccess:onSuccess onFailure:onFailure];
}

+ (void) setHighScore:(int64_t)score withDisplayText:(NSString*)displayText forLeaderboard:(NSString*)leaderboardId silently:(BOOL)silently onSuccess:(const OFDelegate&)onSuccess onFailure:(const OFDelegate&)onFailure
{
	OFPointer<OFHttpNestedQueryStringWriter> params = new OFHttpNestedQueryStringWriter;
	OFRetainedPtr<NSString> leaderboardIdString = leaderboardId;
	params->io("leaderboard_id", leaderboardIdString);
	
	{
		OFISerializer::Scope high_score(params, "high_score");
		params->io("score", score);
		if (displayText)
		{
			params->io("display_text", displayText);
		}
	}
	
    NSString* lastLoggedInUser = [OpenFeint lastLoggedInUserId];
	[OFHighScoreService localSetHighScore:score forLeaderboard:leaderboardId forUser:lastLoggedInUser displayText:displayText serverDate:nil addToExisting:NO];
	OFDelegate chainedSuccessDelegate([self sharedInstance], @selector(_onSetHighScore:nextCall:), onSuccess);
	//OFDelegate chainedFailedDelegate([self sharedInstance], @selector(_onSetHighScoreFailed:nextCall:), onFailure);
	
	if (!silently)
	{
		OFNotificationData* notice = [OFNotificationData dataWithText:([OpenFeint isOnline] ? @"Submitted High Score" : @"Saved High Score Locally") andCategory:kNotificationCategoryLeaderboard andType:kNotificationTypeSuccess];
		[[OFNotification sharedInstance] showBackgroundNotice:notice andStatus:OFNotificationStatusSuccess andInputResponse:nil];
	}

	[[self sharedInstance]
		postAction:@"client_applications/@me/high_scores.xml"
		withParameters:params
		withSuccess:chainedSuccessDelegate
		withFailure:onFailure
		withRequestType:OFActionRequestSilent
		withNotice:nil];
}

+ (void) batchSetHighScores:(OFHighScoreBatchEntrySeries&)highScoreBatchEntrySeries onSuccess:(const OFDelegate&)onSuccess onFailure:(const OFDelegate&)onFailure optionalMessage:(NSString*)submissionMessage
{
	[OFHighScoreService batchSetHighScores:highScoreBatchEntrySeries silently:NO onSuccess:onSuccess onFailure:onFailure optionalMessage:submissionMessage];
}

+ (void) batchSetHighScores:(OFHighScoreBatchEntrySeries&)highScoreBatchEntrySeries silently:(BOOL)silently onSuccess:(const OFDelegate&)onSuccess onFailure:(const OFDelegate&)onFailure optionalMessage:(NSString*)submissionMessage
{
	
	OFPointer<OFHttpNestedQueryStringWriter> params = new OFHttpNestedQueryStringWriter;
	params->serialize("high_scores", "entry", highScoreBatchEntrySeries);
	
	OFNotificationData* notice = [OFNotificationData dataWithText:submissionMessage ? submissionMessage : @"Submitted High Scores" 
													  andCategory:kNotificationCategoryHighScore
														  andType:kNotificationTypeSubmitting];
	[[self sharedInstance]
	 postAction:@"client_applications/@me/high_scores.xml"
	 withParameters:params
	 withSuccess:onSuccess
	 withFailure:onFailure
	 withRequestType:(silently ? OFActionRequestSilent : OFActionRequestBackground)
	 withNotice:notice];
}

+ (void) getAllHighScoresForLoggedInUser:(const OFDelegate&)onSuccess onFailure:(const OFDelegate&)onFailure optionalMessage:(NSString*)submissionMessage
{
	OFNotificationData* notice = [OFNotificationData dataWithText:submissionMessage ? submissionMessage : @"Downloaded High Scores" 
													  andCategory:kNotificationCategoryHighScore
														  andType:kNotificationTypeDownloading];
	OFPointer<OFHttpNestedQueryStringWriter> params = new OFHttpNestedQueryStringWriter;
	OFRetainedPtr<NSString> me = @"me";
	bool acrossLeaderboards = true;
	params->io("across_leaderboards", acrossLeaderboards);
	params->io("user_id", me);
	
	[[self sharedInstance] 
	 getAction:@"client_applications/@me/high_scores.xml"
	 withParameters:params
	 withSuccess:onSuccess
	 withFailure:onFailure
	 withRequestType:OFActionRequestForeground
	 withNotice:notice];
	
}

@end


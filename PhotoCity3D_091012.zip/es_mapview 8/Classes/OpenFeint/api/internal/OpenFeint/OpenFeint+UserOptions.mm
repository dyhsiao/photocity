////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
/// 
///  Copyright 2009 Aurora Feint, Inc.
/// 
///  Licensed under the Apache License, Version 2.0 (the "License");
///  you may not use this file except in compliance with the License.
///  You may obtain a copy of the License at
///  
///  	http://www.apache.org/licenses/LICENSE-2.0
///  	
///  Unless required by applicable law or agreed to in writing, software
///  distributed under the License is distributed on an "AS IS" BASIS,
///  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
///  See the License for the specific language governing permissions and
///  limitations under the License.
/// 
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////


#import "OpenFeint+UserOptions.h"
#import "OpenFeint+Private.h"
#import "OpenFeint+NSNotification.h"
#import "OFGameProfilePageInfo.h"
#import "OFUser.h"
#import "OFProvider.h"

static const NSString* OpenFeintUserOptionShouldAutomaticallyPromptLogin = @"OpenFeintSettingShouldAutomaticallyPromptLogin";
static const NSString* OpenFeintUserOptionLastLoggedInUserHasSetName = @"OpenFeintSettingLastLoggedInUserHasSetName";
static const NSString* OpenFeintUserOptionLastLoggedInUserHadSetNameOnBootup = @"OpenFeintSettingLastLoggedInUserHadSetNameOnBootup";
static const NSString* OpenFeintUserOptionLastLoggedInUserNonDeviceCredential = @"OpenFeintSettingLastLoggedInUserHasNonDeviceCredential";
static const NSString* OpenFeintUserOptionLastLoggedInUserIsNewUser = @"OpenFeintSettingsLastLoggedInUserIsNewUser";
static const NSString* OpenFeintUserOptionUserFeintApproval = @"OpenFeintUserOptionUserFeintApproval";
static const NSString* OpenFeintUserOptionClientApplicationId = @"OpenFeintSettingClientApplicationId";
static const NSString* OpenFeintUserOptionClientApplicationIconUrl = @"OpenFeintSettingClientApplicationIconUrl";
static const NSString* OpenFeintUserOptionUnviewedChallengesCount = @"OpenFeintSettingUnviewedChallengesCount";
static const NSString* OpenFeintUserOptionUserHasRememberedChoiceForNotifications = @"OpenFeintUserOptionUserHasRememberedChoiceForNotifications";
static const NSString* OpenFeintUserOptionUserAllowsNotifications = @"OpenFeintUserOptionUserAllowsNotifications";
static const NSString* OpenFeintUserOptionLastLoggedInUserHasChatEnabled = @"OpenFeintUserOptionLastLoggedInUserHasChatEnabled";
static const NSString* OpenFeintUserOptionLocalGameInfo = @"OpenFeintUserOptionLocalGameInfo";
static const NSString* OpenFeintUserOptionLocalUser = @"OpenFeintUserOptionLocalUser";

@implementation OpenFeint (UserOptions)

+ (void)intiailizeUserOptions
{
	NSData* user = [NSKeyedArchiver archivedDataWithRootObject:[OFUser invalidUser]];
	NSData* game = [NSKeyedArchiver archivedDataWithRootObject:[OFGameProfilePageInfo defaultInfo]];
	
	NSUserDefaults *defaults = [NSUserDefaults standardUserDefaults];
	NSDictionary *appDefaults = [NSDictionary dictionaryWithObjectsAndKeys:
								 @"YES", OpenFeintUserOptionShouldAutomaticallyPromptLogin,
								 @"YES", OpenFeintUserOptionLastLoggedInUserHasChatEnabled,
								 user, OpenFeintUserOptionLocalUser,
								 game, OpenFeintUserOptionLocalGameInfo,
								 nil
								 ];

	[defaults registerDefaults:appDefaults];
}

+ (void)setDontAutomaticallyPromptLogin
{
	[[NSUserDefaults standardUserDefaults] setObject:@"NO" forKey:OpenFeintUserOptionShouldAutomaticallyPromptLogin];
}

+ (bool)shouldAutomaticallyPromptLogin
{
	return [[NSUserDefaults standardUserDefaults] boolForKey:OpenFeintUserOptionShouldAutomaticallyPromptLogin];
}

+ (void)setUserApprovedFeint
{
	[[NSUserDefaults standardUserDefaults] setObject:@"YES" forKey:OpenFeintUserOptionUserFeintApproval];
}

+ (void)setUserDeniedFeint
{
	[[NSUserDefaults standardUserDefaults] setObject:@"NO" forKey:OpenFeintUserOptionUserFeintApproval];
}

+ (bool)hasUserSetFeintAccess
{
	return [[NSUserDefaults standardUserDefaults] stringForKey:OpenFeintUserOptionUserFeintApproval] != nil;
}

+ (bool)_hasUserApprovedFeint
{
	return [[[NSUserDefaults standardUserDefaults] stringForKey:OpenFeintUserOptionUserFeintApproval] isEqualToString:@"YES"];
}

+ (void)_resetHasUserSetFeintAccess
{
#if defined(_DEBUG) || defined(DEBUG)
	[[NSUserDefaults standardUserDefaults] removeObjectForKey:OpenFeintUserOptionUserFeintApproval];
	[OpenFeint setLocalUser:[OFUser invalidUser]];
	[[OpenFeint provider] destroyLocalCredentials];
#endif
}

+ (NSString*)lastLoggedInUserId
{
	return [[OpenFeint localUser] resourceId];
}

+ (NSString*)lastLoggedInUserProfilePictureUrl
{
	return [[OpenFeint localUser] profilePictureUrl];
}

+ (BOOL)lastLoggedInUserUsesFacebookProfilePicture
{
	return [[OpenFeint localUser] usesFacebookProfilePicture];
}

+ (NSString*)lastLoggedInUserName
{
	return [[OpenFeint localUser] name];
}

+ (void)setLoggedInUserHasSetName:(BOOL)hasSetName
{
	[[NSUserDefaults standardUserDefaults] setObject:[NSNumber numberWithBool:hasSetName] forKey:OpenFeintUserOptionLastLoggedInUserHasSetName];
}

+ (BOOL)lastLoggedInUserHasSetName
{
	NSNumber* asNumber = [[NSUserDefaults standardUserDefaults] objectForKey:OpenFeintUserOptionLastLoggedInUserHasSetName];
	return asNumber && [asNumber boolValue];
}

+ (void)setLoggedInUserHadFriendsOnBootup:(BOOL)hadFriends
{
	[[NSUserDefaults standardUserDefaults] setObject:[NSNumber numberWithBool:hadFriends] forKey:OpenFeintUserOptionLastLoggedInUserHadSetNameOnBootup];
}

+ (BOOL)lastLoggedInUserHadFriendsOnBootup
{
	NSNumber* asNumber = [[NSUserDefaults standardUserDefaults] objectForKey:OpenFeintUserOptionLastLoggedInUserHadSetNameOnBootup];
	return asNumber && [asNumber boolValue];
}

+ (void)setLoggedInUserHasNonDeviceCredential:(BOOL)hasNonDeviceCredential
{
	[[NSUserDefaults standardUserDefaults] setObject:[NSNumber numberWithBool:hasNonDeviceCredential] forKey:OpenFeintUserOptionLastLoggedInUserNonDeviceCredential];
}

+ (BOOL)loggedInUserHasNonDeviceCredential
{
	NSNumber* asNumber = [[NSUserDefaults standardUserDefaults] objectForKey:OpenFeintUserOptionLastLoggedInUserNonDeviceCredential];
	return asNumber && [asNumber boolValue];
}

+ (void)setLoggedInUserIsNewUser:(BOOL)isNewUser
{
	[[NSUserDefaults standardUserDefaults] setObject:[NSNumber numberWithBool:isNewUser] forKey:OpenFeintUserOptionLastLoggedInUserIsNewUser];
}

+ (BOOL)loggedInUserIsNewUser
{
	NSNumber* asNumber = [[NSUserDefaults standardUserDefaults] objectForKey:OpenFeintUserOptionLastLoggedInUserIsNewUser];
	return asNumber && [asNumber boolValue];
}

+ (void)setClientApplicationId:(NSString*)clientApplicationId
{
	[[NSUserDefaults standardUserDefaults] setObject:clientApplicationId forKey:OpenFeintUserOptionClientApplicationId];
}

+ (NSString*)clientApplicationId
{
	return [[NSUserDefaults standardUserDefaults] stringForKey:OpenFeintUserOptionClientApplicationId];
}

+ (void)setClientApplicationIconUrl:(NSString*)clientApplicationIconUrl
{
	[[NSUserDefaults standardUserDefaults] setObject:clientApplicationIconUrl forKey:OpenFeintUserOptionClientApplicationIconUrl];
}

+ (NSString*)clientApplicationIconUrl
{
	return [[NSUserDefaults standardUserDefaults] stringForKey:OpenFeintUserOptionClientApplicationIconUrl];
}

+ (void)setUnviewedChallengesCount:(NSInteger)numChallenges
{
	[[NSUserDefaults standardUserDefaults] setInteger:numChallenges forKey:OpenFeintUserOptionUnviewedChallengesCount];
	[UIApplication sharedApplication].applicationIconBadgeNumber = numChallenges;
	[OpenFeint postUnviewedChallengeCountChangedTo:numChallenges];
}

+ (NSInteger)unviewedChallengesCount
{
	return [[NSUserDefaults standardUserDefaults] integerForKey:OpenFeintUserOptionUnviewedChallengesCount];
}

+ (void)setUserHasRememberedChoiceForNotifications:(BOOL)hasRememberedChoice
{
	[[NSUserDefaults standardUserDefaults] setBool:hasRememberedChoice
											forKey:OpenFeintUserOptionUserHasRememberedChoiceForNotifications];
}

+ (BOOL)userHasRememberedChoiceForNotifications
{
	return [[NSUserDefaults standardUserDefaults] boolForKey:OpenFeintUserOptionUserHasRememberedChoiceForNotifications];
}

+ (void)setUserAllowsNotifications:(BOOL)allowed
{
	[[NSUserDefaults standardUserDefaults] setBool:allowed
											forKey:OpenFeintUserOptionUserAllowsNotifications];
}

+ (BOOL)userAllowsNotifications
{
	return [[NSUserDefaults standardUserDefaults] boolForKey:OpenFeintUserOptionUserAllowsNotifications];
}

+ (void)setLoggedInUserHasChatEnabled:(BOOL)enabled
{
	[[NSUserDefaults standardUserDefaults] setBool:enabled forKey:OpenFeintUserOptionLastLoggedInUserHasChatEnabled];
}

+ (BOOL)loggedInUserHasChatEnabled
{
	return [[NSUserDefaults standardUserDefaults] boolForKey:OpenFeintUserOptionLastLoggedInUserHasChatEnabled];
}

+ (BOOL)appHasAchievements {
	return [[OpenFeint localGameProfileInfo] hasAchievements];
}

+ (BOOL)appHasChallenges {
	return [[OpenFeint localGameProfileInfo] hasChallenges];
}

+ (BOOL)appHasLeaderboards {
	return [[OpenFeint localGameProfileInfo] hasLeaderboards];
}

+ (void)setLocalGameProfileInfo:(OFGameProfilePageInfo*)profileInfo
{
	NSData* encoded = [NSKeyedArchiver archivedDataWithRootObject:profileInfo];
	[[NSUserDefaults standardUserDefaults] setObject:encoded forKey:OpenFeintUserOptionLocalGameInfo];
}

+ (OFGameProfilePageInfo*)localGameProfileInfo
{
	NSData* encoded = [[NSUserDefaults standardUserDefaults] objectForKey:OpenFeintUserOptionLocalGameInfo];
	return (OFGameProfilePageInfo*)[NSKeyedUnarchiver unarchiveObjectWithData:encoded];
}

+ (void)setLocalUser:(OFUser*)user
{
	OFUser* previousUser = [self localUser];

	NSData* encoded = [NSKeyedArchiver archivedDataWithRootObject:user];
	[[NSUserDefaults standardUserDefaults] setObject:encoded forKey:OpenFeintUserOptionLocalUser];

	[OpenFeint postUserChangedNotificationFromUser:previousUser toUser:user];
}

+ (OFUser*)localUser
{
	NSData* encoded = [[NSUserDefaults standardUserDefaults] objectForKey:OpenFeintUserOptionLocalUser];
	return (OFUser*)[NSKeyedUnarchiver unarchiveObjectWithData:encoded];
}

+ (void)loggedInUserChangedNameTo:(NSString*)name
{
	[OpenFeint setLoggedInUserHasSetName:YES];
	OFUser* user = [self localUser];
	user.name = name;
	[self setLocalUser:user];
}

@end
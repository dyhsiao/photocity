/*
 *  OpenFeint+NSNotification.mm
 *  OpenFeint
 *
 *  Created by Andy Dill on 9/9/09.
 *  Copyright 2009 Aurora Feint. All rights reserved.
 *
 */

#import "OpenFeint+NSNotification.h"
#import "OFUser.h"

NSString const* OFNSNotificationUserChanged = @"OFNSNotificationUserChanged";

NSString const* OFNSNotificationInfoPreviousUser = @"OFNSNotificationInfoPreviousUser";
NSString const* OFNSNotificationInfoCurrentUser = @"OFNSNotificationInfoCurrentUser";

NSString const* OFNSNotificationUnviewedChallengeCountChanged = @"OFNSNotificationUnviewedChallengeCountChanged";

NSString const* OFNSNotificationInfoUnviewedChallengeCount = @"OFNSNotificationInfoUnviewedChallengeCount";

@implementation OpenFeint (NSNotification)

+ (void)postUserChangedNotificationFromUser:(OFUser*)from toUser:(OFUser*)to
{
	NSDictionary* userInfo = [NSDictionary dictionaryWithObjectsAndKeys:from, OFNSNotificationInfoPreviousUser, to, OFNSNotificationInfoCurrentUser, nil];
	[[NSNotificationCenter defaultCenter] postNotificationName:OFNSNotificationUserChanged object:nil userInfo:userInfo];
}

+ (void)postUnviewedChallengeCountChangedTo:(NSUInteger)unviewedChallengeCount
{
	NSDictionary* userInfo = [NSDictionary dictionaryWithObjectsAndKeys:[NSNumber numberWithUnsignedInteger:unviewedChallengeCount], OFNSNotificationInfoUnviewedChallengeCount, nil];
	[[NSNotificationCenter defaultCenter] postNotificationName:OFNSNotificationUnviewedChallengeCountChanged object:nil userInfo:userInfo];
}

@end
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
/// 
///  Copyright 2009 Aurora Feint, Inc.
/// 
///  Licensed under the Apache License, Version 2.0 (the "License");
///  you may not use this file except in compliance with the License.
///  You may obtain a copy of the License at
///  
///  	http://www.apache.org/licenses/LICENSE-2.0
///  	
///  Unless required by applicable law or agreed to in writing, software
///  distributed under the License is distributed on an "AS IS" BASIS,
///  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
///  See the License for the specific language governing permissions and
///  limitations under the License.
/// 
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

#import "OFBadgeButton.h"

@interface OFBadgeButton (Internal)
- (void)_positionBadge;
- (void)_calcContentInset;
@end

@implementation OFBadgeButton

- (void)dealloc
{
	OFSafeRelease(badgeLabel);
	OFSafeRelease(badgeBackground);
	[super dealloc];
}

- (void)awakeFromNib
{
	CGRect parentRect = self.frame;
	badgeBackgroundOffset = CGPointMake(badgeBackground.frame.origin.x - parentRect.origin.x, 
										badgeBackground.frame.origin.y - parentRect.origin.y);
	
	badgeLabelOffset = CGPointMake(badgeLabel.frame.origin.x - parentRect.origin.x, 
									badgeLabel.frame.origin.y - parentRect.origin.y);
	
	badgeLabel.hidden = YES;
	badgeBackground.hidden = YES;
	awaken = true;
	
	[self _positionBadge];
	[super awakeFromNib];
}

- (void)didMoveToSuperview
{
	[super didMoveToSuperview];
	[[self superview] insertSubview:badgeBackground aboveSubview:self];
	[[self superview] insertSubview:badgeLabel aboveSubview:badgeBackground];
}

- (void)_positionBadge
{
	if (awaken)
	{
		CGRect bgRect = CGRectMake(self.frame.origin.x + badgeBackgroundOffset.x, 
								   self.frame.origin.y + badgeBackgroundOffset.y, 
								   badgeBackground.frame.size.width, 
								   badgeBackground.frame.size.height);
		badgeBackground.frame = bgRect;
		
		CGRect labelRect = CGRectMake(self.frame.origin.x + badgeLabelOffset.x, 
									  self.frame.origin.y + badgeLabelOffset.y, 
									  badgeLabel.frame.size.width, 
									  badgeLabel.frame.size.height);
		badgeLabel.frame = labelRect;		
	}
}

- (void)layoutSubviews
{
	[self _positionBadge];
	[super layoutSubviews];
}

- (void)setFrame:(CGRect)_frame
{
	[super setFrame:_frame];
	[self _positionBadge];
}

- (void)setCenter:(CGPoint)_center
{
	[super setCenter:_center];
	[self _positionBadge];
}

- (void)setBadgeNumber:(NSUInteger)badgeNumber
{
	if (badgeNumber == 0)
	{
		badgeBackground.hidden = YES;
		badgeLabel.hidden = YES;
	}
	else
	{
		badgeBackground.hidden = NO;
		badgeLabel.hidden = NO;
		badgeLabel.text = [NSString stringWithFormat:@"%u", badgeNumber];
	}
}

@end
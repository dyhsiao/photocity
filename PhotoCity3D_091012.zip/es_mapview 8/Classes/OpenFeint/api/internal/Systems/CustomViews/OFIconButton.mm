////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
/// 
///  Copyright 2009 Aurora Feint, Inc.
/// 
///  Licensed under the Apache License, Version 2.0 (the "License");
///  you may not use this file except in compliance with the License.
///  You may obtain a copy of the License at
///  
///  	http://www.apache.org/licenses/LICENSE-2.0
///  	
///  Unless required by applicable law or agreed to in writing, software
///  distributed under the License is distributed on an "AS IS" BASIS,
///  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
///  See the License for the specific language governing permissions and
///  limitations under the License.
/// 
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

#import "OFIconButton.h"
#import "OFImageLoader.h"

@interface OFIconButton (Internal)
- (void)_positionIcon;
- (void)_calcContentInset;
@end

@implementation OFIconButton

- (void)awakeFromNib
{
	[super awakeFromNib];

	[self _positionIcon];
	[self _calcContentInset];
}

- (void)dealloc
{
	OFSafeRelease(iconView);
	[super dealloc];
}

- (void)_setupBackground
{
	UIImage* normalImage = [OFImageLoader loadImage:@"OFDefaultButtonWithIcon.png"];
	UIImage* selectedImage = [OFImageLoader loadImage:@"OFDefaultButtonWithIconDown.png"];
	
	const int kButtonLeftCapWidth = 32;
	[self setBackgroundImage:[normalImage stretchableImageWithLeftCapWidth:kButtonLeftCapWidth topCapHeight:0] forState:UIControlStateNormal];
	[self setBackgroundImage:[selectedImage stretchableImageWithLeftCapWidth:kButtonLeftCapWidth topCapHeight:0] forState:UIControlStateSelected];
}

- (void)_positionIcon
{
	float const kIconCenterOffset = 38.f;
	CGPoint centerPoint = CGPointMake(self.frame.size.width - kIconCenterOffset, floorf(self.frame.size.height * 0.5f) + 1.f);
	centerPoint.x += self.frame.origin.x;
	centerPoint.y += self.frame.origin.y;
	iconView.center = centerPoint;
}

- (void)_calcContentInset
{
	NSString* text = self.currentTitle;
	CGSize textSize = [text sizeWithFont:buttonFont];

	float const kIconFrameSize = 64.f;
	float const kLeftMargin = 32.f;
	float leftInset = floorf((self.frame.size.width - kIconFrameSize - kLeftMargin - textSize.width) * 0.5f);
	
	self.contentHorizontalAlignment = UIControlContentHorizontalAlignmentLeft;
	self.contentEdgeInsets = UIEdgeInsetsMake(0.f, leftInset + kLeftMargin, 0.f, 0.f);
}

- (void)setFrame:(CGRect)_frame
{
	[super setFrame:_frame];
	[self _positionIcon];
	[self _calcContentInset];
}

- (void)setTitleForAllStates:(NSString*)buttonTitle
{
	[super setTitleForAllStates:buttonTitle];
	[self _calcContentInset];
}

- (void)setHidden:(BOOL)_hidden
{
	[super setHidden:_hidden];
	iconView.hidden = _hidden;
}

@end
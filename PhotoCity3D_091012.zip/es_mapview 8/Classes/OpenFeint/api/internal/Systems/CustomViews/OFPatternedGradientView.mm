////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
/// 
///  Copyright 2009 Aurora Feint, Inc.
/// 
///  Licensed under the Apache License, Version 2.0 (the "License");
///  you may not use this file except in compliance with the License.
///  You may obtain a copy of the License at
///  
///  	http://www.apache.org/licenses/LICENSE-2.0
///  	
///  Unless required by applicable law or agreed to in writing, software
///  distributed under the License is distributed on an "AS IS" BASIS,
///  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
///  See the License for the specific language governing permissions and
///  limitations under the License.
/// 
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

#import "OFPatternedGradientView.h"
#import "OFImageLoader.h"
#import "OpenFeint+Private.h"

@implementation OFPatternedGradientView

@synthesize patternImage = mPattern;

+ (id)defaultView
{
	NSString* gradientImage = ([OpenFeint isInLandscapeMode]) ? @"OFTableGradientLandscape.png" : @"OFTableGradient.png";
	OFPatternedGradientView* bgView = [[[OFPatternedGradientView alloc] 
		initWithFrame:[OpenFeint getDashboardBounds]
		andGradientImage:gradientImage 
		andPatternImage:@"OFTablePattern.png"] autorelease];
		
	return bgView;
}

- (id)initWithFrame:(CGRect)frame andGradientImage:(NSString*)gradientImageName andPatternImage:(NSString*)patternImageName;
{
	self = [super initWithFrame:frame];
	if (self != nil)
	{
		self.opaque = YES;
		self.autoresizingMask = UIViewAutoresizingFlexibleWidth | UIViewAutoresizingFlexibleHeight;

		if ([gradientImageName length] > 0)
		{
			mGradient = [[OFImageLoader loadImage:gradientImageName] retain];
		}
		
		if ([patternImageName length] > 0)
		{
			mPattern = [[OFImageLoader loadImage:patternImageName] retain];
		}
	}
	
	return self;
}

- (void)dealloc
{
	OFSafeRelease(mGradient);
	OFSafeRelease(mPattern);
	
	[super dealloc];
}

- (void)drawRect:(CGRect)rect
{
	[mPattern drawAsPatternInRect:rect];
	
	if (mGradient)
	{
		CGRect gradientRect = rect;
		gradientRect.origin.y = CGRectGetMaxY(rect) - mGradient.size.height;
		gradientRect.origin.y = MAX(gradientRect.origin.y, 0.f);
		gradientRect.size.height = CGRectGetMaxY(rect) - gradientRect.origin.y;
		
		[mGradient drawInRect:gradientRect];
	}
}

@end
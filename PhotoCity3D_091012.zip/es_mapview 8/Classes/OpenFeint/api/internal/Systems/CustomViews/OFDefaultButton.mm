////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
/// 
///  Copyright 2009 Aurora Feint, Inc.
/// 
///  Licensed under the Apache License, Version 2.0 (the "License");
///  you may not use this file except in compliance with the License.
///  You may obtain a copy of the License at
///  
///  	http://www.apache.org/licenses/LICENSE-2.0
///  	
///  Unless required by applicable law or agreed to in writing, software
///  distributed under the License is distributed on an "AS IS" BASIS,
///  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
///  See the License for the specific language governing permissions and
///  limitations under the License.
/// 
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

#import "OFDefaultButton.h"
#import "OFColors.h"
#import "OFImageLoader.h"
#import "IPhoneOSIntrospection.h"
#import "NSObject+WeakLinking.h"

@implementation OFDefaultButton

- (void)_setupBackground
{
	UIImage* normalImage = [OFImageLoader loadImage:@"OFDefaultButton.png"];
	UIImage* selectedImage = [OFImageLoader loadImage:@"OFDefaultButtonDown.png"];
	
	const int kButtonLeftCapWidth = 32;
	const int kButtonTopCapHeight = 42;
	[self setBackgroundImage:[normalImage stretchableImageWithLeftCapWidth:kButtonLeftCapWidth topCapHeight:kButtonTopCapHeight] forState:UIControlStateNormal];
	[self setBackgroundImage:[selectedImage stretchableImageWithLeftCapWidth:kButtonLeftCapWidth topCapHeight:kButtonTopCapHeight] forState:UIControlStateSelected];
}

- (void)_commonInit
{
	[self _setupBackground];
	
	UIFont* currentFont = (UIFont*)[self tryGet:@"titleLabel.font" elseGet:@"font"];
	CGFloat pointSize = currentFont.pointSize;
	
	buttonFont = [[UIFont fontWithName:@"Arial-BoldMT" size:pointSize] retain];
	CGSize shadowOffset = CGSizeMake(-1.f, 1.f);
	
#ifndef __IPHONE_3_0	
	[(id)self setTitleShadowOffset:shadowOffset];
#else
	if (is2PointOhSystemVersion())
		[(id)self setTitleShadowOffset:shadowOffset];
	else if (is3PointOhSystemVersion())
		[self.titleLabel setShadowOffset:shadowOffset];
#endif
	
	[self trySet:@"titleLabel.font" elseSet:@"font" with:(id)buttonFont];
	
	UIColor* magicColor = [UIColor colorWithRed:0.f green:0.f blue:0.f alpha:1.f];
	UIColor* magicColor2 = [UIColor colorWithWhite:0.f alpha:1.f];
	if (CGColorEqualToColor(self.currentTitleColor.CGColor, magicColor.CGColor) ||
		CGColorEqualToColor(self.currentTitleColor.CGColor, magicColor2.CGColor))
	{
		[self setTextColorForAllStates:OFColors::defaultGreyColor];
		[self setTextShadowColorForAllStates:[UIColor blackColor]];
	}
}

- (id)initWithCoder:(NSCoder*)aDecoder
{
	self = [super initWithCoder:aDecoder];
	if (self != nil)
	{
		[self _commonInit];
	}
	
	return self;
}

- (id)initWithFrame:(CGRect)frame
{
	self = [super initWithFrame:frame];
	if (self != nil)
	{
		[self _commonInit];
	}
	
	return self;
}

- (id)init
{
	self = [super init];
	if (self != nil)
	{
		[self _commonInit];
	}
	return self;
}

- (void)setTitleForAllStates:(NSString*)buttonTitle
{
	[self setTitle:buttonTitle forState:UIControlStateNormal];
	[self setTitle:buttonTitle forState:UIControlStateDisabled];
	[self setTitle:buttonTitle forState:UIControlStateSelected];
	[self setTitle:buttonTitle forState:UIControlStateHighlighted];
}

- (void)setTextColorForAllStates:(UIColor*)textColor
{
	[self setTitleColor:textColor forState:UIControlStateNormal];
	[self setTitleColor:textColor forState:UIControlStateDisabled];
	[self setTitleColor:textColor forState:UIControlStateSelected];
	[self setTitleColor:textColor forState:UIControlStateHighlighted];
}

- (void)setTextShadowColorForAllStates:(UIColor*)shadowColor
{
	[self setTitleShadowColor:shadowColor forState:UIControlStateNormal];
	[self setTitleShadowColor:shadowColor forState:UIControlStateDisabled];
	[self setTitleShadowColor:shadowColor forState:UIControlStateSelected];
	[self setTitleShadowColor:shadowColor forState:UIControlStateHighlighted];
}

- (void)dealloc
{
	OFSafeRelease(buttonFont);
	[super dealloc];
}

@end
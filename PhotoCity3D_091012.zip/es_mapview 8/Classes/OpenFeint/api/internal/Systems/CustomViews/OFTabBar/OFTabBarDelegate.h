//
//  OFTabBarDelegate.h
//  OpenFeint
//
//  Created by Jason Citron on 7/18/09.
//  Copyright 2009 Aurora Feint Inc.. All rights reserved.
//

@class OFTabBar;
@class OFTabBarItem;

@protocol OFTabBarDelegate<NSObject>

@optional
- (void)tabBar:(OFTabBar*)tabBar didSelectViewController:(UIViewController *)viewController;
- (UIViewController*)tabBar:(OFTabBar*)tabBarController loadViewController:(NSString*)viewControllerName forTab:(OFTabBarItem*)tabItem;
- (void)tabBar:(OFTabBar*)tabBarController didLoadViewController:(UIViewController*)viewController fromTab:(OFTabBarItem*)tabItem;

- (void)tabBar:(OFTabBar*)tabBar didSelectTabItem:(OFTabBarItem*)tabItem;
- (void)tabBar:(OFTabBar*)tabBar didSelectTabNamed:(NSString*)tabName;
- (void)tabBar:(OFTabBar*)tabBar didSelectTabAtIndex:(int)index;

- (void)tabBar:(OFTabBar*)tabBar didDisableTabItem:(OFTabBarItem*)tabItem;
- (void)tabBar:(OFTabBar*)tabBar didDisableTabNamed:(NSString*)tabName;
- (void)tabBar:(OFTabBar*)tabBar didDisableTabAtIndex:(int)index;

@end
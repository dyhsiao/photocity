////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
/// 
///  Copyright 2009 Aurora Feint, Inc.
/// 
///  Licensed under the Apache License, Version 2.0 (the "License");
///  you may not use this file except in compliance with the License.
///  You may obtain a copy of the License at
///  
///  	http://www.apache.org/licenses/LICENSE-2.0
///  	
///  Unless required by applicable law or agreed to in writing, software
///  distributed under the License is distributed on an "AS IS" BASIS,
///  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
///  See the License for the specific language governing permissions and
///  limitations under the License.
/// 
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

#import "OFDependencies.h"
#import "OFFormControllerHelper+EditingSupport.h"
#import "OFFormControllerHelper+Submit.h"
#import "OFViewHelper.h"
#import "OFFormControllerHelper+Overridables.h"
#import "OpenFeint+Private.h"

@implementation OFFormControllerHelper ( EditingSupport )

- (void)_KeyboardDidShow:(NSNotification*)notification
{
    if (mIsKeyboardShown)
	{
		return;
	}
		
    NSDictionary* info = [notification userInfo];
 
    NSValue* aValue = [info objectForKey:UIKeyboardBoundsUserInfoKey];
    CGSize keyboardSize = [aValue CGRectValue].size;

    CGRect viewFrame = [mScrollContainerView frame];
	CGPoint screenSpaceOrigin = [mScrollContainerView convertPoint:viewFrame.origin toView:[OpenFeint getTopLevelView]];
	mViewHeightWithoutKeyboard = viewFrame.size.height;
	float bottomOfView = [OpenFeint getDashboardBounds].size.height - keyboardSize.height;
	viewFrame.size.height = bottomOfView - screenSpaceOrigin.y;
	
	[UIView beginAnimations:nil context:nil];
	[UIView setAnimationDuration:0.3f];		
    mScrollContainerView.frame = viewFrame;
	[UIView commitAnimations];

	CGRect rectToMakeVisible = mActiveTextField.frame;
	if ([mActiveTextField superview] != mScrollContainerView)
	{
		rectToMakeVisible.origin.x += [[mActiveTextField superview] frame].origin.x;
		rectToMakeVisible.origin.y += [[mActiveTextField superview] frame].origin.y;
//		rectToMakeVisible.origin = [mActiveTextField convertPoint:rectToMakeVisible.origin toView:mScrollContainerView];
	}
	[mScrollContainerView scrollRectToVisible:rectToMakeVisible animated:YES];
 
    mIsKeyboardShown = YES;
}

- (void)_KeyboardDidHide:(NSNotification*)notification
{
    if (!mIsKeyboardShown)
	{
		return;
	}

    CGRect viewFrame = [mScrollContainerView frame];
    viewFrame.size.height = mViewHeightWithoutKeyboard;

	[UIView beginAnimations:nil context:nil];
	[UIView setAnimationDuration:0.3f];		
    mScrollContainerView.frame = viewFrame;
	[UIView commitAnimations];
	
    mIsKeyboardShown = NO;
}

- (void)textFieldDidBeginEditing:(UITextField *)textField
{
	mActiveTextField = textField;

	CGRect rectToMakeVisible = mActiveTextField.frame;
	if ([mActiveTextField superview] != mScrollContainerView)
	{
		rectToMakeVisible.origin.x += [[mActiveTextField superview] frame].origin.x;
		rectToMakeVisible.origin.y += [[mActiveTextField superview] frame].origin.y;
//		rectToMakeVisible.origin = [mActiveTextField convertPoint:rectToMakeVisible.origin toView:mScrollContainerView];
	}
	[mScrollContainerView scrollRectToVisible:rectToMakeVisible animated:YES];
}

- (BOOL)textFieldShouldReturn:(UITextField *)textField
{
	UIResponder* nextView = OFViewHelper::findViewByTag(self.view, textField.tag + 1);

	if(nextView != nil)
	{
		if([nextView isKindOfClass:[UITextField class]])
		{
			[nextView becomeFirstResponder];
		}
		else
		{
			[textField resignFirstResponder];
		}
	}
	else
	{		
		[self onSubmitForm:textField];
	}
	
	return YES;
}

@end

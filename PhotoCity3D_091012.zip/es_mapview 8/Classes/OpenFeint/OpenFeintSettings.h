////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
/// 
///  Copyright 2009 Aurora Feint, Inc.
/// 
///  Licensed under the Apache License, Version 2.0 (the "License");
///  you may not use this file except in compliance with the License.
///  You may obtain a copy of the License at
///  
///  	http://www.apache.org/licenses/LICENSE-2.0
///  	
///  Unless required by applicable law or agreed to in writing, software
///  distributed under the License is distributed on an "AS IS" BASIS,
///  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
///  See the License for the specific language governing permissions and
///  limitations under the License.
/// 
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

#pragma once

////////////////////////////////////////////////////////////
///
/// @type		NSNumber bool
/// @default	false
/// @behavior	When false, OpenFeint will attempt to acquire access keys in the background. On success
///				or failure, the user will be notified via a non-interrupting pop-up notification.
///
///				When true, OpenFeint will attempt to acquire access keys in the foreground. If your game
///				has not been authorized by the user, he will be prompted to authorize your game. If a user 
///				does not have an OpenFeint account, he will be required to create one. This authorization process
///				will not be skippable. Once authorization is complete, the OpenFeint dashboard will dismiss itself.
///
///	@warning	Setting this value to true will effectively require a user have an OpenFeint account and be 
///				online when using your game.
///
////////////////////////////////////////////////////////////
extern const NSString* OpenFeintSettingRequireAuthorization;

////////////////////////////////////////////////////////////
///
/// @type		NSNumber UIInterfaceOrientation
/// @default	UIInterfaceOrientationPortrait
/// @behavior	Defines what orientation the OpenFeint dashboard launches in. The dashboard does not auto rotate.
///
////////////////////////////////////////////////////////////
extern const NSString* OpenFeintSettingDashboardOrientation;


////////////////////////////////////////////////////////////
///
/// @type		NSString 
/// @default	Your application's (short) display name.
/// @behavior	Used as the game tab's title
///
////////////////////////////////////////////////////////////
extern const NSString* OpenFeintSettingShortDisplayName;

////////////////////////////////////////////////////////////
///
/// @type		NSNumber bool
/// @default	false 
/// @behavior	Allows this application to send and receive Push Notifications. Only available on OS 3.0.
///				If set to true you must call OpenFeint::applicationDidRegisterForRemoteNotificationsWithDeviceToken
///				and OpenFeint::applicationDidFailToRegisterForRemoteNotifications from your UIApplicationDelegate
///
////////////////////////////////////////////////////////////
extern const NSString* OpenFeintSettingEnablePushNotifications;

////////////////////////////////////////////////////////////
///
/// @type		NSNumber bool
/// @default	false 
/// @behavior	When a user enters the OpenFeint dashboard they will be unable to access the chat functionality
///
////////////////////////////////////////////////////////////
extern const NSString* OpenFeintSettingDisableChat;

////////////////////////////////////////////////////////////
///
/// @type		NSNumber bool
/// @default	false 
/// @behavior	If this is true then the application will prompt the user to approve OpenFeint every time the
///				application launches in DEBUG mode only. This makes testing custom approval screens easier.
///
////////////////////////////////////////////////////////////
extern const NSString* OpenFeintSettingAlwaysAskForApprovalInDebug;

////////////////////////////////////////////////////////////
///
/// @type		UIWindow
/// @default	nil
/// @behavior	You can specify a UIWindow here which will be the window that OpenFeint launches it's dashboard
///				in and the window that OpenFeint displays it's notification views in. If you *do not* specify a
///				UIWindow here OpenFeint will choose the UIApplication's keyWindow, and failing that it will
///				choose the first of the UIApplication's UIWindow objects.
///
////////////////////////////////////////////////////////////
extern const NSString* OpenFeintSettingPresentationWindow;

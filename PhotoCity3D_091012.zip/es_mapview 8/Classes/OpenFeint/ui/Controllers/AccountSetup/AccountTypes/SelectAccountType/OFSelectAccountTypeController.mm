////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
/// 
///  Copyright 2009 Aurora Feint, Inc.
/// 
///  Licensed under the Apache License, Version 2.0 (the "License");
///  you may not use this file except in compliance with the License.
///  You may obtain a copy of the License at
///  
///  	http://www.apache.org/licenses/LICENSE-2.0
///  	
///  Unless required by applicable law or agreed to in writing, software
///  distributed under the License is distributed on an "AS IS" BASIS,
///  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
///  See the License for the specific language governing permissions and
///  limitations under the License.
/// 
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

#import "OFDependencies.h"
#import "OFSelectAccountTypeController.h"
#import "OFControllerLoader.h"
#import "OFFacebookAccountController.h"
#import "OpenFeint+UserOptions.h"
#import "OpenFeint+Private.h"
#import "OFUseNewOrOldAccountController.h"

@implementation OFSelectAccountTypeController

@synthesize socialNetworkNotice;
@synthesize openFeintNotice;	
@synthesize neverShowLostAccountWarning;

- (BOOL)shouldShowLostAccountWarning
{
	return !neverShowLostAccountWarning && ![OpenFeint loggedInUserHasNonDeviceCredential];
}

- (void)_pushAccountSetupControllerFor:(NSString*)containerName
{
	OFAccountSetupBaseController* accountController = (OFAccountSetupBaseController*)OFControllerLoader::load([NSString stringWithFormat:@"%@AccountLogin", containerName]);
	[accountController setCancelDelegate:mCancelDelegate];
	[accountController setCompletionDelegate:mCompletionDelegate];
	[[self navigationController] pushViewController:accountController animated:YES];
}

- (void)actionSheet:(UIActionSheet *)actionSheet clickedButtonAtIndex:(NSInteger)buttonIndex
{
	if (buttonIndex == 0)
	{
		[self _pushAccountSetupControllerFor:mControllerToOpen.get()];
	}
}

- (void)_showAccountSetupFor:(NSString*)containerName
{
	if ([self shouldShowLostAccountWarning])
	{
		mControllerToOpen = containerName;
		NSString* warning = [OFUseNewOrOldAccountController _getWarningText];
		UIActionSheet* warningSheet = [[[UIActionSheet alloc] initWithTitle:warning delegate:self cancelButtonTitle:@"Cancel" destructiveButtonTitle:@"Switch Account Anyway" otherButtonTitles:nil] autorelease];
		[warningSheet showInView:[OpenFeint getTopLevelView]];
	}
	else
	{
		[self _pushAccountSetupControllerFor:containerName];
	}
}

- (void)_onPressedTwitter
{
	[self _showAccountSetupFor:@"Twitter"];
}

- (void)_onPressedFacebook
{
	[self _showAccountSetupFor:@"Facebook"];
}

- (void)registerActionsNow
{
	[self registerAction:OFDelegate(self, @selector(_onPressedTwitter)) forTag:2];	
	[self registerAction:OFDelegate(self, @selector(_onPressedFacebook)) forTag:3];		
}

- (void)dealloc
{
	self.socialNetworkNotice = nil;
	self.openFeintNotice = nil;
	[super dealloc];
}

@end

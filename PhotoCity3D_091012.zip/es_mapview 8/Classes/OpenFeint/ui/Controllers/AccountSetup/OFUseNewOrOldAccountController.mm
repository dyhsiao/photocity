////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
/// 
///  Copyright 2009 Aurora Feint, Inc.
/// 
///  Licensed under the Apache License, Version 2.0 (the "License");
///  you may not use this file except in compliance with the License.
///  You may obtain a copy of the License at
///  
///  	http://www.apache.org/licenses/LICENSE-2.0
///  	
///  Unless required by applicable law or agreed to in writing, software
///  distributed under the License is distributed on an "AS IS" BASIS,
///  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
///  See the License for the specific language governing permissions and
///  limitations under the License.
/// 
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

#import "OFUseNewOrOldAccountController.h"
#import "OFControllerLoader.h"
#import "OpenFeint+UserOptions.h"
#import "OpenFeint+Private.h"
#import "OFAccountLoginController.h"
#import "OFProvider.h"
#import "OFNewAccountController.h"

@implementation OFUseNewOrOldAccountController

@synthesize warningText;
@synthesize warningView;
@synthesize contentView;
@synthesize scrollView;

+ (NSString*)_getWarningText
{
	return [NSString stringWithFormat:@"%@ has not been secured. If you switch accounts you will lose all OpenFeint data for all games associated with %@. To secure your account, click Secure Account under Settings in the OpenFeint Dashboard.", [OpenFeint lastLoggedInUserName], [OpenFeint lastLoggedInUserName]];
}

- (NSString*)getFormSubmissionUrl
{
	return @"";
}

- (void)registerActionsNow
{
}

- (NSString*)singularResourceName
{
	return @"";
}

- (void)onFormSubmitted
{
}

- (BOOL)shouldShowLostAccountWarning
{
	return ![OpenFeint loggedInUserHasNonDeviceCredential];
}

- (void)viewWillAppear:(BOOL)animated
{
	[super viewWillAppear:animated];
	
	if ([self shouldShowLostAccountWarning])
	{
		self.warningView.hidden = NO;		
		self.warningText.text = [OFUseNewOrOldAccountController _getWarningText];
	}
	else
	{
		CGRect frame = self.contentView.frame;
		frame.origin.y -= self.warningView.frame.size.height;
		self.contentView.frame = frame;
	}
	
	CGSize totalContentSize = self.contentView.frame.size;
	totalContentSize.height += self.contentView.frame.origin.y;
	self.scrollView.contentSize = totalContentSize;
}

- (void)viewDidDisappear:(BOOL)animated
{
	[super viewDidDisappear:animated];
	
	if (![self shouldShowLostAccountWarning])
	{
		CGRect frame = self.contentView.frame;
		frame.origin.y += self.warningView.frame.size.height;
		self.contentView.frame = frame;
	}
}

- (void)onNewAccountCreated
{
	[self hideLoadingScreen];
	OFNewAccountController* newAccountController = (OFNewAccountController*)OFControllerLoader::load(@"StandardNewAccount");
	
	if (mCompletionDelegate.isValid())
	{
		[newAccountController setCompleteDelegate:mCompletionDelegate];
	}
	else
	{
		OFDelegate popToRootDelegate(self, @selector(popBackToRoot));
		[newAccountController setCompleteDelegate:popToRootDelegate];
	}
	
	if (mCancelDelegate.isValid())
	{
		//[newAccountController setCancelDelegate:mCancelDelegate];
	}
	
	[self.navigationController pushViewController:newAccountController animated:YES];
}

- (void)popBackToRoot
{
	[OpenFeint reloadInactiveTabBars];
	[self.navigationController popToRootViewControllerAnimated:YES];
}

- (void)onFailedCreatingNewAccount
{
	[self hideLoadingScreen];
}

- (void)createNewAccount
{
	[self showLoadingScreen];
	[[OpenFeint provider] destroyLocalCredentials];
	[OpenFeint doBootstrap:true 
				 onSuccess:OFDelegate(self, @selector(onNewAccountCreated)) 
				 onFailure:OFDelegate(self, @selector(onFailedCreatingNewAccount))];
}

- (void)goToAccountLogin
{
	OFAccountSetupBaseController* login = (OFAccountSetupBaseController*)OFControllerLoader::load(@"OpenFeintAccountLogin");

	if (mCompletionDelegate.isValid())
	{
		[login setCompletionDelegate:mCompletionDelegate];
	}
	else
	{
		OFDelegate popToRootDelegate(self, @selector(popBackToRoot));
		[login setCompletionDelegate:popToRootDelegate];
	}
	
	if (mCancelDelegate.isValid())
	{
		[login setCancelDelegate:mCancelDelegate];
	}

	[self.navigationController pushViewController:login animated:YES];
}

- (void)showActionSheetWarning
{
	NSString* warning = [OFUseNewOrOldAccountController _getWarningText];
	UIActionSheet* warningSheet = [[[UIActionSheet alloc] initWithTitle:warning delegate:self cancelButtonTitle:@"Cancel" destructiveButtonTitle:@"Switch Account Anyway" otherButtonTitles:nil] autorelease];
	[warningSheet showInView:[OpenFeint getTopLevelView]];
}

- (void)actionSheet:(UIActionSheet *)actionSheet clickedButtonAtIndex:(NSInteger)buttonIndex
{
	if (buttonIndex == actionSheet.destructiveButtonIndex)
	{
		if (creatingNew)
		{
			[self createNewAccount];
		}
		else
		{
			[self goToAccountLogin];
		}	
	}
	actionSheet.delegate = nil;
}

-(IBAction)clickedCreateNew
{
	if ([self shouldShowLostAccountWarning])
	{
		creatingNew = YES;
		[self showActionSheetWarning];
	}
	else
	{
		[self createNewAccount];
	}
	
}

-(IBAction)clickedUseOld
{
	if ([self shouldShowLostAccountWarning])
	{
		creatingNew = NO;
		[self showActionSheetWarning];
	}
	else
	{
		[self goToAccountLogin];
	}
}

- (void)dealloc
{
	self.warningText = nil;
	self.warningView = nil;
	self.contentView = nil;
	self.scrollView = nil;
	[super dealloc];
}


@end
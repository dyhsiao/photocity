////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
/// 
///  Copyright 2009 Aurora Feint, Inc.
/// 
///  Licensed under the Apache License, Version 2.0 (the "License");
///  you may not use this file except in compliance with the License.
///  You may obtain a copy of the License at
///  
///  	http://www.apache.org/licenses/LICENSE-2.0
///  	
///  Unless required by applicable law or agreed to in writing, software
///  distributed under the License is distributed on an "AS IS" BASIS,
///  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
///  See the License for the specific language governing permissions and
///  limitations under the License.
/// 
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

#import "OFProfileHeaderView.h"

#import "OFUser.h"
#import "OFImageView.h"
#import "OFProfileController.h"
#import "OFControllerLoader.h"
#import "OFFramedNavigationController.h"
#import "OFProfileComparisonUser.h"
#import "OFImageLoader.h"

#import "OpenFeint+Private.h"
#import "OpenFeint+UserOptions.h"
#import "OpenFeint+Settings.h"

@implementation OFProfileHeaderView

@synthesize user, comparedWithUser;

- (void)_repositionNonComparisonHeaderElements
{
	float const kRightMargin = 11.f;

	float scoreWidth = [feintScoreLabel.text sizeWithFont:feintScoreLabel.font].width;
	float previousOriginX = 0.f;
	
	CGRect frame = feintScoreLabel.frame;
	frame.origin.x = containerView.bounds.size.width - scoreWidth - kRightMargin;
	frame.size.width = scoreWidth;
	previousOriginX = frame.origin.x;
	feintScoreLabel.frame = frame;
	
	frame = feintScoreIconView.frame;
	frame.origin.x = previousOriginX - feintScoreIconView.image.size.width;
	previousOriginX = frame.origin.x;
	feintScoreIconView.frame = frame;
	
	frame = feintNameLabel.frame;
	frame.size.width = previousOriginX - frame.origin.x;
	feintNameLabel.frame = frame;
}

- (void)_userChanged:(OFUser*)_user
{
	OFSafeRelease(user);
	user = [_user retain];

	bool isLocalUser = [user isLocalUser];
	if (isLocalUser)
	{
		[feintPictureView setDefaultImage:[OFImageLoader loadImage:@"OFProfileIconDefaultSelf.png"]];
	}
	else
	{
		[feintPictureView setDefaultImage:[OFImageLoader loadImage:@"OFProfileIconDefault.png"]];
	}
	
	feintNameLabel.text = user.name;
	feintPictureView.useFacebookOverlay = NO;
	feintPictureView.imageUrl = user.profilePictureUrl;

	if([OpenFeint isOnline])
		[self setOnlineHeader];
	else 
		[self setOfflineHeader];

	[self _repositionNonComparisonHeaderElements];

	if (isComparing)
	{
		[self animateInUsers];
	}
}

- (void)changeUserTo:(OFUser*)_user comparedWith:(OFUser*)_comparedWithUser
{
	[self _userChanged:_user];

	OFSafeRelease(comparedWithUser);
	comparedWithUser = [_comparedWithUser retain];	

	leftUser.user = user;
	rightUser.user = comparedWithUser;
}

- (bool)canReceiveCallbacksNow
{
	return true;
}

- (void)awakeFromNib
{
	if ([OpenFeint isInLandscapeMode])
	{
		containerView.transform = CGAffineTransformMake(0.f, -1.f, 1.f, 0.f, 0.f, 0.f);
		feintPictureView.transform = CGAffineTransformMake(0.f, 1.f, -1.f, 0.f, 0.f, 0.f);
		
		landscapeBorderView.hidden = NO;
	}

	// adill note: some issue with OFImageView border path when the view is transformed.
	//  we don't need it to be clipped here anyway, since it's under the frame overlay.
	feintPictureView.useSharpCorners = YES;

	overlayView.contentMode = UIViewContentModeScaleToFill;
	overlayView.image = [overlayView.image stretchableImageWithLeftCapWidth:31 topCapHeight:0];

	compareIcon.image = [OFImageLoader loadImage:@"OFProfileFrameCompareIconOn.png"];
	
	// explicitly weak-reference owner
	[owner release];
}

- (void)setFrame:(CGRect)_frame
{
	[super setFrame:_frame];

	if ([OpenFeint isInLandscapeMode])
	{
		CGRect bounds = containerView.bounds;
		bounds.size.width = _frame.size.height;
		bounds.size.height = _frame.size.width;
		containerView.bounds = bounds;
		
		containerView.center = CGPointMake(
			bounds.size.height * 0.5f,
			bounds.size.width * 0.5f
		);
	}
	else
	{
		_frame.origin = CGPointZero;
		containerView.frame = _frame;
	}

	float textWidth = [compareLabel.text sizeWithFont:compareLabel.font].width;
	float const iconSpacing = 4.f;
	float const arbitraryWidthPadding = 10.f;
	float const iconWidth = compareIcon.frame.size.width;
	float const totalWidth = containerView.bounds.size.width;
	float const maxTextWidth = totalWidth - iconWidth - iconSpacing - arbitraryWidthPadding;
	if (textWidth > maxTextWidth)
		textWidth = maxTextWidth;
	
	float originX = roundf(0.5f * (totalWidth - textWidth - iconWidth - iconSpacing));
	
	CGRect labelFrame = compareLabel.frame;
	labelFrame.origin.x = originX + iconWidth + iconSpacing;
	labelFrame.size.width = textWidth;
	compareLabel.frame = labelFrame;

	CGRect iconFrame = compareIcon.frame;
	iconFrame.origin.x = originX;
	iconFrame.origin.y = labelFrame.origin.y - 1.f;
	compareIcon.frame = iconFrame;
	
	if (!isComparing)
	{
		[self _repositionNonComparisonHeaderElements];
	}
}

- (void)touchesEnded:(NSSet*)touches withEvent:(UIEvent*)event
{
	if (!isOfflineHeader)
	{
		if (!isComparisonEnabled)
		{
			[OFProfileController showProfileForUser:user];
		}
		else
		{
			[owner compareButtonPressed];
		}
	}
}

- (void) setOfflineHeader
{
	isOfflineHeader = YES;
	feintScoreIconView.hidden = YES;
	if ([OpenFeint hasUserApprovedFeint])
	{
		feintScoreLabel.hidden = NO;
		feintScoreLabel.text = @"offline";
		feintScoreLabel.textColor = [UIColor colorWithRed:248.f/255.f green:129.f/255.f blue:2.f/255.f alpha:1.f];
	}
	else
	{
		feintScoreLabel.hidden = YES;
	}
	[self _repositionNonComparisonHeaderElements];
}

- (void) setOnlineHeader
{
	isOfflineHeader = NO;
	feintScoreIconView.hidden = NO;
	feintScoreLabel.hidden = NO;
	feintScoreLabel.text = [NSString stringWithFormat:@"%d", user.gamerScore];
	feintScoreLabel.textColor = [UIColor whiteColor];
	[self _repositionNonComparisonHeaderElements];
}

- (void)_positionComparisonElementsOffscreen
{
	CGRect frame = leftUser.frame;
	frame.origin = CGPointMake(-frame.size.width, 0.f);
	leftUser.frame = frame;

	frame = rightUser.frame;
	frame.origin = CGPointMake(containerView.bounds.size.width, 0.f);
	rightUser.frame = frame;
}

- (void)animateInUsers
{
	leftUser.user = user;
	rightUser.user = comparedWithUser;

	[UIView beginAnimations:nil context:nil];
	[UIView setAnimationDuration:0.325f];

	CGRect frame = leftUser.frame;
	frame.origin = CGPointZero;
	leftUser.frame = frame;

	frame = rightUser.frame;
	frame.origin = CGPointMake(containerView.bounds.size.width - frame.size.width, 0.f);
	rightUser.frame = frame;

	vsImageView.alpha = 1.f;

	[UIView commitAnimations];

	[containerView insertSubview:leftUser belowSubview:overlayView];
	[containerView insertSubview:rightUser belowSubview:overlayView];
}

- (void)finishedRepositioningFrame
{
	if (isComparing)
	{
		if (!leftUser || !rightUser)
		{
			OFSafeRelease(leftUser);
			OFSafeRelease(rightUser);
			
			leftUser = [(OFProfileComparisonUser*)OFControllerLoader::loadView(@"ProfileCompareUserLeft") retain];
			rightUser = [(OFProfileComparisonUser*)OFControllerLoader::loadView(@"ProfileCompareUserRight") retain];

			[self _positionComparisonElementsOffscreen];
		}
		
		[self animateInUsers];
	}
	else
	{
		[leftUser removeFromSuperview];
		[rightUser removeFromSuperview];

		OFSafeRelease(leftUser);
		OFSafeRelease(rightUser);
	}
}

- (void)setComparisonEnabled:(BOOL)_isComparisonEnabled
{
	isComparisonEnabled = _isComparisonEnabled;

	float newSize = 37.f;
	if (isComparisonEnabled)
	{
		compareIcon.alpha = 1.f;
		compareLabel.alpha = 1.f;
		newSize = 47.f;
	}
	else
	{
		compareIcon.alpha = 0.f;
		compareLabel.alpha = 0.f;
	}

	CGRect frame = self.frame;
	if ([OpenFeint isInLandscapeMode])
		frame.size.width = newSize;
	else
		frame.size.height = newSize;

	[self setFrame:frame];
}

- (void)setComparing:(BOOL)_isComparing;
{	
	isComparing = _isComparing;

	if (isComparing)
	{
		compareIcon.image = [OFImageLoader loadImage:@"OFProfileFrameCompareIconOff.png"];
		compareLabel.text = [NSString stringWithFormat:@"Stop comparing with %@", comparedWithUser.name];

		feintPictureView.alpha = 0.f;
		feintScoreLabel.alpha = 0.f;
		feintScoreIconView.alpha = 0.f;
		feintNameLabel.alpha = 0.f;
		rightDivider.alpha = 1.f;
	}
	else
	{
		compareIcon.image = [OFImageLoader loadImage:@"OFProfileFrameCompareIconOn.png"];
		compareLabel.text = @"Compare with a Friend";

		feintPictureView.alpha = 1.f;
		feintScoreLabel.alpha = 1.f;
		feintScoreIconView.alpha = 1.f;
		feintNameLabel.alpha = 1.f;
		rightDivider.alpha = 0.f;
		vsImageView.alpha = 0.f;
		
		[self _positionComparisonElementsOffscreen];
	}
}

- (void)dealloc
{
	OFSafeRelease(user);
	OFSafeRelease(comparedWithUser);

	OFSafeRelease(containerView);
	OFSafeRelease(overlayView);
	OFSafeRelease(leftDivider);
	OFSafeRelease(rightDivider);
	OFSafeRelease(compareLabel);
	OFSafeRelease(compareIcon);
	OFSafeRelease(landscapeBorderView);

	OFSafeRelease(feintScoreIconView);
	OFSafeRelease(feintNameLabel);
	OFSafeRelease(feintScoreLabel);
	OFSafeRelease(feintPictureView);
	
	OFSafeRelease(vsImageView);
	OFSafeRelease(leftUser);
	OFSafeRelease(rightUser);

	[super dealloc];
}

@end
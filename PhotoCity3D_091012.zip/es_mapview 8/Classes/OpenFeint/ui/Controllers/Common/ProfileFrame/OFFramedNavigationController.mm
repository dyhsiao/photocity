////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
/// 
///  Copyright 2009 Aurora Feint, Inc.
/// 
///  Licensed under the Apache License, Version 2.0 (the "License");
///  you may not use this file except in compliance with the License.
///  You may obtain a copy of the License at
///  
///  	http://www.apache.org/licenses/LICENSE-2.0
///  	
///  Unless required by applicable law or agreed to in writing, software
///  distributed under the License is distributed on an "AS IS" BASIS,
///  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
///  See the License for the specific language governing permissions and
///  limitations under the License.
/// 
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

#import "OFDependencies.h"
#import "OFFramedNavigationController.h"
#import "OFProfileFrame.h"
#import "OFControllerLoader.h"
#import "OFFramedContentWrapperView.h"
#import "OFContentFrameView.h"
#import "OFProfileHeaderView.h"
#import "OFLoadingController.h"
#import "OFCustomBottomView.h"
#import "OFTableControllerHelper.h"
#import "OFUser.h"
#import "OFGameProfilePageInfo.h"

#import "IPhoneOSIntrospection.h"

#import "OpenFeint+NSNotification.h"
#import "OpenFeint+UserOptions.h"
#import "OpenFeint+Private.h"

#pragma mark OFFramedControllerInfo Interface

@interface OFFramedControllerInfo : NSObject
{
	UIViewController* controller;
	OFUser* user;
	OFUser* comparedToUser;
	OFGameProfilePageInfo* clientApplicationInfo;
}

@property (nonatomic, retain) OFUser* user;
@property (nonatomic, retain) OFUser* comparedToUser;
@property (nonatomic, retain) OFGameProfilePageInfo* clientApplicationInfo;
@property (nonatomic, readonly) UIViewController* controller;

+ (id)withController:(UIViewController*)_controller andClientApplicationInfo:(OFGameProfilePageInfo*)_clientApplicationInfo;

@end

#pragma mark OFFramedControllerInfo Implementation

@implementation OFFramedControllerInfo

@synthesize user, comparedToUser, clientApplicationInfo, controller;

+ (id)withController:(UIViewController*)_controller andClientApplicationInfo:(OFGameProfilePageInfo*)_clientApplicationInfo
{
	OFFramedControllerInfo* info = [[[OFFramedControllerInfo alloc] init] autorelease];
	info->controller = [_controller retain];
	info.clientApplicationInfo = _clientApplicationInfo;
	return info;
}

- (void)dealloc
{
	OFSafeRelease(controller);
	self.user = nil;
	self.comparedToUser = nil;
	self.clientApplicationInfo = nil;
	[super dealloc];
}

@end

#pragma mark OFFramedNavigationController Internal Interface

@interface OFFramedNavigationController (Internal)
- (void)_pushViewController:(UIViewController*)controller animated:(BOOL)animated inContextOfUser:(OFUser*)userContext comparedToUser:(OFUser*)comparedToUser;
- (void)_changeUserTo:(OFUser*)user comparedWith:(OFUser*)comparedWithUser notifyController:(BOOL)notifyController;
- (void)_positionViewsForController:(UIViewController*)viewController animated:(BOOL)animated;
- (void)_updateLoadingViewPosition;
- (void)_userChanged:(NSNotification*)notification;
@end

#pragma mark OFFramedNavigationController Implementation

@implementation OFFramedNavigationController

@synthesize owningTabBarItem, headerView;

- (void)showLoadingIndicator
{
	[super showLoadingIndicator];
	
	[mLoadingController.view removeFromSuperview];
	[self.view insertSubview:mLoadingController.view belowSubview:frameView];
}

- (id)initWithRootViewController:(UIViewController *)rootViewController
{
	self = [super initWithRootViewController:rootViewController];
	if (self != nil)
	{
		[[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(_userChanged:) name:OFNSNotificationUserChanged object:nil];
	}
	
	return self;
}

- (id)init
{
	self = [super init];
	if (self != nil)
	{
		[[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(_userChanged:) name:OFNSNotificationUserChanged object:nil];
	}
	
	return self;
}

- (void)dealloc
{
	[[NSNotificationCenter defaultCenter] removeObserver:self];

	OFSafeRelease(controllerInfos);
	
	[headerView removeFromSuperview];
	OFSafeRelease(headerView);
	
	[frameView removeFromSuperview];
	OFSafeRelease(frameView);
	
	[customBottomView removeFromSuperview];
	OFSafeRelease(customBottomView);
	
	[super dealloc];
}

- (void)viewDidLoad
{
	[super viewDidLoad];

	CGRect frame;
	
	controllerInfos = [[NSMutableArray arrayWithCapacity:16] retain];
	
	OFSafeRelease(headerView);
	headerView = [(OFProfileHeaderView*)OFControllerLoader::loadView(@"ProfileHeader", self) retain];

	OFSafeRelease(frameView);
	frameView = [(OFContentFrameView*)OFControllerLoader::loadView(@"ContentFrame") retain];

	isProfileHeaderVisible = YES;

	if ([OpenFeint isInLandscapeMode])
	{
		frame = headerView.frame;
		frame.origin.y = self.navigationBar.frame.size.height;
		frame.size.width = frame.size.height;
		frame.size.height = headerView.frame.size.width;
		headerView.frame = frame;

		frame = frameView.frame;
		frame.origin.x = CGRectGetMaxX(headerView.frame);
		frame.origin.y = self.navigationBar.frame.size.height;
		frame.size.width -= frame.origin.x;
		frame.size.height -= frame.origin.y;
		frameView.frame = frame;
	}
	else
	{
		frame = headerView.frame;
		frame.origin.y = self.navigationBar.frame.size.height;
		headerView.frame = frame;

		frame = frameView.frame;
		frame.origin.y = CGRectGetMaxY(headerView.frame);
		frame.size.height -= frame.origin.y;
		frameView.frame = frame;
	}
	
	[self.view addSubview:frameView];
	[self.view addSubview:headerView];

	[self.view bringSubviewToFront:self.navigationBar];
}

- (void)setNavigationBarHidden:(BOOL)hidden animated:(BOOL)animated
{
	if (animated)
	{
		[UIView beginAnimations:@"navBarAdjustment" context:nil];
		[UIView setAnimationDuration:0.22f];
	}
		
	[super setNavigationBarHidden:hidden animated:animated];

	CGRect frame;

	frame = headerView.frame;
	frame.origin.y = hidden ? 0.f : self.navigationBar.frame.size.height;
	headerView.frame = frame;

	if ([OpenFeint isInLandscapeMode])
	{
		frame = frameView.frame;
		frame.origin.y = hidden ? 0.f : self.navigationBar.frame.size.height;
		frameView.frame = frame;
	}
	else
	{
		frame = frameView.frame;
		frame.origin.y = CGRectGetMaxY(headerView.frame);
		frameView.frame = frame;
	}
		
	if (animated)
	{
		[UIView commitAnimations];
	}
}

- (OFUser*)currentUser
{
	OFUser* currentUser = [headerView user];
	return !currentUser ? [OpenFeint localUser] : currentUser;
}

- (OFUser*)comparisonUser
{
	return [headerView comparedWithUser];
}

- (OFGameProfilePageInfo*)currentGameContext
{
	OFFramedControllerInfo* fci = [controllerInfos lastObject];
	return fci.clientApplicationInfo;
}

- (void)changeGameContext:(OFGameProfilePageInfo*)_gameContext
{
	OFFramedControllerInfo* fci = [controllerInfos lastObject];
	fci.clientApplicationInfo = _gameContext;
}

- (void)pushViewController:(UIViewController*)controller animated:(BOOL)animated inContextOfUser:(OFUser*)user
{
	[self _pushViewController:controller animated:animated inContextOfUser:user comparedToUser:nil];
}

- (void)pushViewController:(UIViewController*)controller animated:(BOOL)animated inContextOfLocalUserComparedTo:(OFUser*)user
{
	[self _pushViewController:controller animated:animated inContextOfUser:[OpenFeint localUser] comparedToUser:user];
}

- (void)pushViewController:(UIViewController*)controller animated:(BOOL)animated
{
	[self _pushViewController:controller animated:animated inContextOfUser:[self currentUser] comparedToUser:nil];
}

- (void)_pushViewController:(UIViewController*)controller animated:(BOOL)animated inContextOfUser:(OFUser*)userContext comparedToUser:(OFUser*)comparedToUser
{
	[self.view bringSubviewToFront:self.navigationBar];

	if (![controller.view isKindOfClass:[OFFramedContentWrapperView class]])
	{
		UIView* contentView = controller.view;
		OFFramedContentWrapperView* wrapperView = [[[OFFramedContentWrapperView alloc] initWithWrappedView:contentView] autorelease];
		[controller setView:wrapperView];
		[wrapperView setContentInsets:[OFContentFrameView getContentInsets]];
	}

	OFGameProfilePageInfo* clientAppContext = [[controllerInfos lastObject] clientApplicationInfo];
	[controllerInfos addObject:[OFFramedControllerInfo withController:controller andClientApplicationInfo:clientAppContext]];

	[super pushViewController:controller animated:animated];

	if (!comparedToUser)
	{
		comparedToUser = [headerView comparedWithUser];
	}
	
	[self _changeUserTo:userContext comparedWith:comparedToUser notifyController:NO];
}

- (UIViewController *)popViewControllerAnimated:(BOOL)animated
{
	UIViewController* popped = [super popViewControllerAnimated:animated];

	[controllerInfos removeLastObject];
	OFFramedControllerInfo* cui = [controllerInfos lastObject];
	[self _changeUserTo:cui.user comparedWith:cui.comparedToUser notifyController:NO];

	return popped;
}

- (NSArray *)popToViewController:(UIViewController *)viewController animated:(BOOL)animated
{
	NSArray* returned = [super popToViewController:viewController animated:animated];

	int numPopped = [returned count];
	for (int i = 0; i < numPopped; ++i)
		[controllerInfos removeLastObject];

	OFFramedControllerInfo* cui = [controllerInfos lastObject];
	[self _changeUserTo:cui.user comparedWith:cui.comparedToUser notifyController:NO];
	
	return returned;
}

- (NSArray *)popToRootViewControllerAnimated:(BOOL)animated
{
	NSArray* returned = [super popToRootViewControllerAnimated:animated];
	
	int numPopped = [returned count];
	for (int i = 0; i < numPopped; ++i)
		[controllerInfos removeLastObject];

	OFFramedControllerInfo* cui = [controllerInfos lastObject];
	[self _changeUserTo:cui.user comparedWith:cui.comparedToUser notifyController:YES];

	return returned;
}

- (void)navigationController:(UINavigationController *)navigationController willShowViewController:(UIViewController *)viewController animated:(BOOL)animated
{
	if (animated)
	{
		// this makes the animations look a lot more polished
		// because the view we're about to show may already be at it's correct
		// insets but we want to force it to animate with the frame
		UIEdgeInsets contentInsets = [OFContentFrameView getContentInsets];
		if ([OpenFeint isInLandscapeMode])
			contentInsets.left += isProfileHeaderVisible ? headerView.frame.size.width : 0.f;
		else
			contentInsets.top += isProfileHeaderVisible ? headerView.frame.size.height : 0.f;
		[(OFFramedContentWrapperView*)viewController.view setContentInsets:contentInsets];
	}
	
	[super navigationController:navigationController willShowViewController:viewController animated:animated];

	if (!animated)
	{
		[self _positionViewsForController:viewController animated:NO];
	}
}

- (void)animationDidStop:(NSString*)animId finished:(NSNumber*)finished context:(void*)context
{
	if (animId == @"slideOutCustomBottom")
	{
		isCustomBottomViewAnimatingOut = NO;
		[customBottomView removeFromSuperview];
		OFSafeRelease(customBottomView);
	}
	else if (animId == @"framedNavReposition")
	{
		[headerView finishedRepositioningFrame];
	}
}

- (void)navigationController:(UINavigationController *)navigationController didShowViewController:(UIViewController *)viewController animated:(BOOL)animated
{
	[super navigationController:navigationController didShowViewController:viewController animated:animated];

	if ([viewController conformsToProtocol:@protocol(OFCustomBottomView)])
	{
		[customBottomView removeFromSuperview];
		OFSafeRelease(customBottomView);

		customBottomView = [[(UIViewController<OFCustomBottomView>*)viewController getBottomView] retain];

		CGRect frame = customBottomView.frame;
		frame.origin.y = self.view.frame.size.height;
		customBottomView.frame = frame;

		[self.view addSubview:customBottomView];
	}
	else
	{
		isCustomBottomViewAnimatingOut = YES;
		
		[UIView beginAnimations:@"slideOutCustomBottom" context:nil];
		[UIView setAnimationDuration:0.325f];
		[UIView setAnimationDelegate:self];
		[UIView setAnimationDidStopSelector:@selector(animationDidStop:finished:context:)];
		CGRect frame = customBottomView.frame;
		frame.origin.y += frame.size.height;
		customBottomView.frame = frame;
		[UIView commitAnimations];
	}

	if (animated)
	{
		[self _positionViewsForController:viewController animated:animated];
	}

	[self _updateLoadingViewPosition];
}

- (void)refreshProfile
{
	if ([[headerView user] isLocalUser])
	{
		[headerView changeUserTo:[OpenFeint localUser] comparedWith:[headerView comparedWithUser]];
		[self _positionViewsForController:self.topViewController animated:NO];
	}
}

- (void)refreshBottomView
{
	[customBottomView removeFromSuperview];
	OFSafeRelease(customBottomView);

	if ([self.topViewController conformsToProtocol:@protocol(OFCustomBottomView)])
	{
		customBottomView = [[(UIViewController<OFCustomBottomView>*)self.topViewController getBottomView] retain];

		CGRect frame = customBottomView.frame;
		frame.origin.y = self.view.frame.size.height;
		customBottomView.frame = frame;

		[self.view addSubview:customBottomView];
	}

	[self _positionViewsForController:self.topViewController animated:NO];
}

- (void)adjustForKeyboard:(BOOL)_isKeyboardShown ofSize:(CGSize)_keyboardSize
{
	isKeyboardShown = _isKeyboardShown;
	keyboardSize = _keyboardSize;

	[self _positionViewsForController:self.topViewController animated:YES];
}

- (void)_positionViewsForController:(UIViewController*)viewController animated:(BOOL)animated
{
	if (animated)
	{
		[UIView beginAnimations:@"framedNavReposition" context:nil];
		[UIView setAnimationDuration:0.325f];
		[UIView setAnimationBeginsFromCurrentState:YES];
		[UIView setAnimationDelegate:self];
	}

	BOOL shouldShowHeader = NO;
	BOOL shouldShowCompare = NO;
	if ([viewController conformsToProtocol:@protocol(OFProfileFrame)])
	{
		shouldShowHeader = YES;
		
		if ([OpenFeint isOnline] && [viewController respondsToSelector:@selector(supportsComparison)])
		{
			shouldShowCompare = [(UIViewController<OFProfileFrame>*)viewController supportsComparison];
		}
	}

	if ([OpenFeint isInLandscapeMode])
	{
		[self setNavigationBarHidden:self.navigationBarHidden animated:NO];
	}

	isComparisonEnabled = shouldShowCompare;
	[headerView setComparisonEnabled:isComparisonEnabled];
	
	BOOL desiredComparisonState = isComparisonEnabled && userWantsCompare;
	if (isComparing != desiredComparisonState)
	{
		isComparing = desiredComparisonState;

		[headerView setComparing:isComparing];
	}
	
	CGRect headerFrame = headerView.frame;
	CGRect frameFrame = frameView.frame;
	
	UIEdgeInsets contentInsets = [OFContentFrameView getContentInsets];

	CGSize frameSize = [(OFFramedContentWrapperView*)viewController.view frame].size;
	frameFrame.size = frameSize;

	if ([OpenFeint isInLandscapeMode])
	{
		if (isProfileHeaderVisible && !shouldShowHeader)
			headerFrame.origin.x = -headerFrame.size.width;
		else if (!isProfileHeaderVisible && shouldShowHeader)
			headerFrame.origin.x = 0.f;

		frameFrame.origin.x = CGRectGetMaxX(headerFrame);

		contentInsets.left += shouldShowHeader ? headerFrame.size.width : 0.f;
		frameFrame.size.width -= shouldShowHeader ? headerFrame.size.width : 0.f;
		
		headerFrame.size.height = frameFrame.size.height;
	}
	else
	{
		if (isProfileHeaderVisible && !shouldShowHeader)
			headerFrame.origin.y = self.navigationBar.frame.size.height - headerFrame.size.height;
		else if (!isProfileHeaderVisible && shouldShowHeader)
			headerFrame.origin.y = self.navigationBar.frame.size.height;

		frameFrame.origin.y = CGRectGetMaxY(headerFrame);

		contentInsets.top += shouldShowHeader ? headerFrame.size.height : 0.f;
		frameFrame.size.height -= shouldShowHeader ? headerFrame.size.height : 0.f;
	}

	if (isKeyboardShown)
	{
		frameFrame.size.height -= keyboardSize.height;
		contentInsets.bottom += keyboardSize.height;
	}
	
	if (self.navigationBarHidden && is2PointOhSystemVersion())
	{
		frameFrame.size.height += self.navigationBar.frame.size.height;
		contentInsets.bottom -= self.navigationBar.frame.size.height;
	}

	if (!isCustomBottomViewAnimatingOut && customBottomView)
	{
		CGRect frame = customBottomView.frame;
		frame.origin.y = CGRectGetMaxY(frameFrame) - frame.size.height;
		customBottomView.frame = frame;
		
		frameFrame.size.height -= frame.size.height;
		contentInsets.bottom += frame.size.height;
	}	
	
	isProfileHeaderVisible = shouldShowHeader;

	[(OFFramedContentWrapperView*)viewController.view setContentInsets:contentInsets];

	headerView.frame = headerFrame;
	frameView.frame = frameFrame;
	
	if (animated)
	{
		[UIView commitAnimations];
	}
}

- (void)_updateLoadingViewPosition
{
	if (![OpenFeint isInLandscapeMode])
		return;

	CGRect frame = mLoadingController.view.frame;
	
	float headerWidth = headerView.frame.size.width;
	
	if (isProfileHeaderVisible)
	{
		frame.origin.x = headerWidth;
		frame.size.width = self.view.frame.size.width - headerWidth;
	}
	else
	{
		frame.origin.x = 0.f;
		frame.size.width = self.view.frame.size.width;
	}

	mLoadingController.view.frame = frame;
}

- (void)_userChanged:(NSNotification*)notification
{
	if ([[notification name] isEqualToString:OFNSNotificationUserChanged])
	{
		OFUser* previousUser = (OFUser*)[[notification userInfo] objectForKey:OFNSNotificationInfoPreviousUser];
		OFUser* currentUser = (OFUser*)[[notification userInfo] objectForKey:OFNSNotificationInfoCurrentUser];

		for (OFFramedControllerInfo* fci in controllerInfos)
		{
			if ([fci.user.resourceId isEqualToString:previousUser.resourceId])
			{
				fci.user = currentUser;
				fci.comparedToUser = nil;
			}
			
			if ([fci.comparedToUser.resourceId isEqualToString:previousUser.resourceId])
			{
				fci.comparedToUser = currentUser;
			}
		}
		
		if ([controllerInfos count] > 0)
		{
			OFFramedControllerInfo* fci = [controllerInfos lastObject];
			[self _changeUserTo:fci.user comparedWith:fci.comparedToUser notifyController:YES];
			[self _positionViewsForController:self.topViewController animated:NO];
		}
	}
}

- (void)_changeUserTo:(OFUser*)user comparedWith:(OFUser*)comparedWithUser notifyController:(BOOL)notifyController
{
	OFFramedControllerInfo* fci = [controllerInfos lastObject];
	fci.user = user;
	fci.comparedToUser = comparedWithUser;

	userWantsCompare = comparedWithUser != nil;
	[headerView changeUserTo:user comparedWith:comparedWithUser];

	if (notifyController && [fci.controller respondsToSelector:@selector(profileUsersChanged:comparedToUser:)])
	{
		[(id)fci.controller profileUsersChanged:user comparedToUser:comparedWithUser];
	}
}

#pragma mark Comparison

- (IBAction)compareButtonPressed
{
	OFGameProfilePageInfo* info = [self currentGameContext];

	if (!isComparisonEnabled || !info)
		return;

	if (isComparing)
	{
		[self _changeUserTo:[OpenFeint localUser] comparedWith:nil notifyController:YES];
		[self _positionViewsForController:self.topViewController animated:YES];
	}
	else
	{
		[OFFriendPickerController launchPickerWithDelegate:self promptText:[NSString stringWithFormat:@"Friends who have %@", info.name] mustHaveApplicationId:info.resourceId];			
	}
}

- (void)pickerFinishedWithSelectedUser:(OFUser*)selectedUser
{
	[self _changeUserTo:[OpenFeint localUser] comparedWith:selectedUser notifyController:YES];
	[self _positionViewsForController:self.topViewController animated:YES];
}

@end
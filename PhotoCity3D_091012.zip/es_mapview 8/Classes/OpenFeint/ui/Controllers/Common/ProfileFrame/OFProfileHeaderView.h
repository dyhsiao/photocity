////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
/// 
///  Copyright 2009 Aurora Feint, Inc.
/// 
///  Licensed under the Apache License, Version 2.0 (the "License");
///  you may not use this file except in compliance with the License.
///  You may obtain a copy of the License at
///  
///  	http://www.apache.org/licenses/LICENSE-2.0
///  	
///  Unless required by applicable law or agreed to in writing, software
///  distributed under the License is distributed on an "AS IS" BASIS,
///  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
///  See the License for the specific language governing permissions and
///  limitations under the License.
/// 
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

#pragma once

#import "OFCallbackable.h"

@class OFImageView;
@class OFUser;
@class OFProfileComparisonUser;
@class OFFramedNavigationController;

@interface OFProfileHeaderView : UIView< OFCallbackable >
{
@package
	IBOutlet OFFramedNavigationController* owner;
	
	OFUser* user;
	OFUser* comparedWithUser;
	
	// Shared header elements
	IBOutlet UIView* containerView;
	IBOutlet UIImageView* overlayView;
	IBOutlet UIImageView* leftDivider;
	IBOutlet UIImageView* rightDivider;
	IBOutlet UILabel* compareLabel;
	IBOutlet UIImageView* compareIcon;
	IBOutlet UIView* landscapeBorderView;

	// Non-comparison header elements
	IBOutlet UIImageView* feintScoreIconView;
	IBOutlet UILabel* feintNameLabel;
	IBOutlet UILabel* feintScoreLabel;
	IBOutlet OFImageView* feintPictureView;	
	BOOL isOfflineHeader;
	
	// Comparison header elements
	IBOutlet UIImageView* vsImageView;
	OFProfileComparisonUser* leftUser;
	OFProfileComparisonUser* rightUser;
	BOOL isComparing;
	BOOL isComparisonEnabled;
}

@property (nonatomic, readonly) OFUser* user;
@property (nonatomic, readonly) OFUser* comparedWithUser;

- (void)changeUserTo:(OFUser*)_user comparedWith:(OFUser*)_comparedWithUser;

- (void)setOfflineHeader;
- (void)setOnlineHeader;

- (void)animateInUsers;
- (void)finishedRepositioningFrame;

- (void)setComparisonEnabled:(BOOL)_isComparisonEnabled;
- (void)setComparing:(BOOL)_isComparing;

@end
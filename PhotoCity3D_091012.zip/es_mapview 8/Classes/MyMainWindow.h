//
//  MyMainWindow.h
//  ImageView
//
//  Created by Dun-Yu Hsiao on 9/30/09.
//  Copyright 2009 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>

@class ImageViewAppDelegate;

@interface MyMainWindow : UIWindow {
	ImageViewAppDelegate *theDelegate;

	CGPoint movingSpan;
	CGPoint movingCenter;  
	
	bool click_Ind;
}

@property (assign, nonatomic) ImageViewAppDelegate *theDelegate;

@end


#import <UIKit/UIKit.h>

@interface ConfView : UIView
{ }

@end
